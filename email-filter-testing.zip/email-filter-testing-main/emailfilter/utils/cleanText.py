from bs4 import BeautifulSoup
import re

def clean_text(text: str) -> str:
    """Cleans text by stripping unwanted characters and html tags.

    Args:
        text (str): Text to clean

    Returns:
        str: Cleaned text
    """
    if text is not None and isinstance(text, str):
        text = text.strip().strip("\n")
        return strip_unwanted_chars(strip_html_tags(text))
    return text

def strip_unwanted_chars(value: str) -> str:
    """Strips ' and " from text.
    
    Args:
        value (str): Text to strip
        
    Returns:
        str: Text with ' and " stripped
    """
    return value.replace("'", "").replace('"', '')

def strip_html_tags(value: str) -> str:
    """Strips html tags from text.
    
    Args:
        value (str | bytes): Text to strip
        
    Returns:
        str: Text with html tags stripped
    """
    if value is not None:
        soup = BeautifulSoup(value, 'html.parser')
        return soup.get_text()
    print("3906 keep_tags value: " + str(value))
    return value

def escape_ansi(line: str) -> str:
    """Removes ansi escape characters from text.
    
    Args:
        line (str): Text to strip
        
    Returns:
        str: Text with ansi escape characters stripped
    """
    ansi_escape = re.compile(r'(\x9B|\x1B\[)[0-?]*[ -/]*[@-~]')
    return ansi_escape.sub('', line)

def replace_wording( subject:str, test_num:str, email_server:str, forward_email_to:str, test_additional_msg:str) -> str:
        """Replaces wording in subject line with test number, email server, and forward email to address.
        
        Args:
            subject (str): Subject line to replace wording in
            test_num (int): Test number
            email_server (str): Email server
            forward_email_to (str): Forward email to address
            
        Returns:
            str: Subject line with wording replaced
        """
        if "TESTNUM" in subject:
            subject = subject.replace("TESTNUM", str(test_num))
        if "EMAILSERVER" in subject:
            subject = subject.replace("EMAILSERVER", str(email_server))
        if "FORWARDTOEMAIL" in subject:
            subject = subject.replace("FORWARDTOEMAIL", str(forward_email_to))
        return subject