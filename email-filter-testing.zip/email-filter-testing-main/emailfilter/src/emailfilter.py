import tempfile
import smtplib
import dns.resolver
import datetime
import time
import sys
import os
import string
import random
import time
import string
import json
from re import match
from argparse import ArgumentTypeError, ArgumentParser, SUPPRESS

sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))

from emailfilter.utils.cleanText import clean_text
from emailfilter.utils.dnsFunctions import grab_dns_record
from emailfilter.utils.networkFunctions import valid_ip
from emailfilter.utils.printText import print_msg, print_error, print_bold
from emailfilter.utils.miscFunctions import create_path
from emailfilter.utils.globals import *
from emailfilter.src.__about__ import __version__

import emailfilter.src.emailTests as emailTests

#--------------------- Email Filter Class -------------------
class EmailFilter():
    def __init__(self, output_directory: str, email_server:str, port:int, email_filter_values: dict[str,str], dns_records: list[str], attachments_path: str, debug: bool, tests_to_run: list[int]=None, ) -> None:
        """Email Filter Class

        Args:
            output_file_path (str): Output directory path
            email_server (str): Email server to send emails to
            port (int): Port to send emails to
            email_filter_values (dict[str,str]): Dictionary of email filter values :'send_read_receipt_to', 'test_additional_msg', 'unsubscribe', 'username', 'passwd',
                'testers_domain', 'public_ip', 'your_ip_address', 'smtp_ehlo_server', 'email_relay_servers_to_bounce_emails_from', 'invalid_user_name', 
                'spoof_domain_no_spf_dmarc_dkim', 'spoof_domain_with_spf_hardfail', 'spoof_domain_with_spf_softfail', 'email_msg_where_to_forward_back_to', 'emailfilter_pause_time', 
                'email_to', 'identification_code', 'num_invalid_domains_to_try'
            dns_records (list[str]): List of DNS records
            attachments_path (str): Path to attachments folder
            debug (bool): Debug mode
            tests_to_run (list[int], optional): List of tests to run. Defaults to None.
        """
        #append the absolute path to the output_file_path
        self.output_folder = os.path.abspath(output_directory)
        self.email_server = email_server
        self.email_public_ip = self.email_server
        self.email_public_ip, additional = grab_dns_record(self.email_server, True) if not valid_ip(self.email_public_ip) else (self.email_public_ip, None) #do dns lookup on email_server dns name if not IP
        self.port = str(port)
        self.dns_records = dns_records
        self.debug = debug
        self.attachment_path = attachments_path
        
        self.sending_order = SENDING_ORDER
        self.tests_that_could_repeat = REPEATABLE_TESTS
        self.test_6_count = 0
        self.test_9_count = 0
        self.test_57_count = 0
        self.test_59_count = 0
        self.test_64_count = 0
        self.test_65_count = 0
        self.test_66_count = 0
        self.test_67_count = 0
        self.test_73_count = 0

        self.email_filter_values = email_filter_values

        self.valid_mail_server = VALID_MAIL_SERVER

        self.send_read_receipt_to = None  # if set, adds read receipt to this email
        self.test_additional_msg = ""
        self.test_additional_body_txt = ""
        self.test_num_prefix = 0
        self.bad_receipient = False
        self.tests_list = tests_to_run if tests_to_run is not None else []

        # Do not run these currently
        if 'send_read_receipt_to' in email_filter_values and 1==3: # NOT CURRENTLY USED
            self.send_read_receipt_to = clean_text(email_filter_values['send_read_receipt_to'])
            self.test_num_prefix = 1000
        self.test_additional_msg = clean_text(email_filter_values['test_additional_msg']) if 'test_additional_msg' in email_filter_values else ""
        if 'unsubscribe' in email_filter_values:
            self.test_num_prefix = 2000
            self.test_additional_msg = "  Email contains a hidden unsubscribe link to decrease SPAM scoring."
            self.test_additional_body_txt = "<p><p><font color=white size=1><a href='http://yourdomain.com/unsubscribe' style='color:white;'>Unsubscribe</a></font>"

        self.smtp_username = None
        self.smtp_username = email_filter_values['username'] if 'username' in email_filter_values else ''
        self.smtp_passwd = None
        self.smtp_passwd = email_filter_values['passwd'] if 'passwd' in email_filter_values else ''
        self.invalid_user_name = INVALID_USER_NAME if 'invalid_user_name' in email_filter_values else None
        if 'spoof_domain_no_spf_dmarc_dkim' in email_filter_values:
            spoof_domain_no_spf_dmarc_dkim = clean_text(email_filter_values['spoof_domain_no_spf_dmarc_dkim'])
            self.spoof_domains_no_spf_dmarc_dkim = [spoof_domain_no_spf_dmarc_dkim]
            if ";" in spoof_domain_no_spf_dmarc_dkim:
                self.spoof_domains_no_spf_dmarc_dkim = spoof_domain_no_spf_dmarc_dkim.split(";")
        
        self.testers_domain = clean_text(email_filter_values['testers_domain']) if 'testers_domain' in email_filter_values else TESTERS_DOMAIN
        self.your_ip_address = clean_text(email_filter_values['your_ip_address']) if 'your_ip_address' in email_filter_values else YOUR_IP_ADDRESS
        self.email_relay_servers_to_bounce_emails_from = clean_text(
            email_filter_values['email_relay_servers_to_bounce_emails_from']) if 'email_relay_servers_to_bounce_emails_from' in email_filter_values else None
        self.smtp_ehlo_server = clean_text(email_filter_values['smtp_ehlo_server']) if 'smtp_ehlo_server' in email_filter_values else SMTP_EHLO_SERVER
        self.spoof_domain_with_spf_hardfail = clean_text(email_filter_values['spoof_domain_with_spf_hardfail']) if "spoof_domain_with_spf_hardfail" in email_filter_values else SPOOF_DOMAIN_WITH_SPF_HARDFAIL
        self.spoof_domain_with_spf_softfail = clean_text(email_filter_values['spoof_domain_with_spf_softfail']) if "spoof_domain_with_spf_softfail" in email_filter_values else SPOOF_DOMAIN_WITH_SPF_SOFTFAIL
        self.forward_email_to = clean_text(email_filter_values['email_msg_where_to_forward_back_to']) if "email_msg_where_to_forward_back_to" in email_filter_values else EMAIL_MSG_WHERE_TO_FORWARD_BACK_TO
        
        self.your_public_ip = clean_text(email_filter_values['public_ip']) if 'public_ip' in email_filter_values else PUBLIC_IP
        self.private_ip = PRIVATE_IP
        
        self.repeat = int(clean_text(email_filter_values['num_invalid_domains_to_try'])) if "num_invalid_domains_to_try" in email_filter_values else 3 # number of invalid domains to try
        self.identification_code = clean_text(email_filter_values['identification_code']) if "identification_code" in email_filter_values else ''.join(random.choices(string.ascii_uppercase + string.digits, k=938)) # random string to identify email sent back to us

        self.client_email = clean_text(email_filter_values['email_to'])
        if "\\" in self.client_email:
            self.client_email = self.client_email.replace("\\", "")

        self.client_username = self.client_email[:self.client_email.find("@")]
        self.domain = self.client_email[self.client_email.find("@") + 1:]  # email_filter_values['client_domain']
        self.pause_time = float(clean_text(email_filter_values['emailfilter_pause_time']))

        # following used for identification on forwarded back email to correctly assign to right test in DB
        self.encrypted_server_info = ''
        self.test_num = ''

        self.start_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')

        self.counter450 = 0
        self.counter421 = 0
        self.test9_count = 0

        self.subject = "Testing Mail Relay TESTNUM through EMAILSERVER. Forward to FORWARDTOEMAIL!"
        if CUSTOM_SUBJECT != "":
            self.subject = CUSTOM_SUBJECT

    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        return self
    
    def change_subject(self, subject:str) -> None:
        """Change the subject line of the email

        Args:
            subject (str): Subject line
        """
        self.subject = subject
	
	# Create emails/ folder and write .eml files for each email
    def create_eml(self, testNum:str, email:str) -> None:
        """Create emails/ folder and write .eml files for each email

        Args:
            testNum (str): Test number
            email (str): Email message to write to file
        """
        
        individual_email_path = os.path.join(os.path.abspath(self.output_folder), f'emails/{self.email_server}/')
        create_path(individual_email_path, self.debug)
        with open(f'{individual_email_path}test#{testNum}.eml', 'w') as emailFile:
            emailFile.write(email)
            
    def mail_relay(self):
        try:
            print_msg("Sending mail relay tests for mail server: " + self.email_server)
            
            # Run tests individually if tests_list is set
            if self.tests_list is not None and len(self.tests_list) > 0:
                not_used_tests = [21, 53, 75, 76, 77]
                if any(test in self.tests_list for test in not_used_tests):
                    print_error("Error: Tests 21, 53, 75, 76, and 77 are not currently supported.")
                    sys.exit(1)
                # if tests are not between 0 and 74 then remove them from the list
                if any(test < 0 or test > 74 for test in self.tests_list):
                    self.tests_list = [test for test in self.tests_list if test >= 0 and test <= 74]
                if len(self.tests_list) <= 0:
                    print_error("Error: No valid tests were provided.")
                    sys.exit(1)
                for test_num in self.tests_list:
                    # if not the last test then add a pause
                    email_test_function = getattr(emailTests, "test" + str(test_num))
                    email_test_function(self, self.output_folder)
                    if test_num != self.tests_list[-1]:
                        time.sleep(self.pause_time)
            # Run all tests
            else:
                for test_num in self.sending_order:
                    # print_error("Sending test " + str(test_num) + " to " + self.email_server)
                    email_test_function = getattr(emailTests, "test" + str(test_num))
                    # print_error("Running test " + str(test_num) + " to " + self.email_server)
                    email_test_function(self, self.output_folder)
                    # print_error("Finished sending test " + str(test_num) + " to " + self.email_server)
                    time.sleep(self.pause_time)
                
                if self.email_server not in self.email_relay_servers_to_bounce_emails_from:
                    time.sleep(self.pause_time)
                    emailTests.test1(self, self.output_folder)  # open relay to from anyone external to anyone external
                    time.sleep(self.pause_time)
                    emailTests.test2(self, self.output_folder)  # open relay from valid internal to anyone external
                time.sleep(self.pause_time)
                
                self._tmp_emailserver = self.email_server
                self.email_server = self.valid_mail_server
                #if self.email_server in self.email_relay_servers_to_bounce_emails_from:
                emailTests.test0(self, self.output_folder)  # should be valid email (so has proper SPF and Rev DNS) used to verify they are not blacklisting us
                self.email_server = self._tmp_emailserver

            # test .docm
            # test embedded exe in pdf
            # .psh
            # .re
            # .res
            # spoof msgRoot['In-Reply-To'] (maybe resend all tests to see if that helps get through SPAM filter
            # spoof msgRoot['References']
            # spoof msgRoot['Thread-Topic']
            # spoof msgRoot['Thread-Index']
            # More headers to spoof at:  https://tools.ietf.org/html/rfc4021 & https://www.iana.org/assignments/message-headers/message-headers.xhtml
            # do test 49 & 46 where 'resent-from' or 'sender' is not a valid email but just user portion or name
            # More headers to spoof http://www.rdns.org/mailtraq/mail/relaying/relay.html (UUCP style bang paths, etc)
            # microsoft word wizards: http://projectwoman.com/2014/10/calendar-wizard-in-word-2013-yes.html
            # calendar invites
            # https://en.wikipedia.org/wiki/MIME#Encoded-Word
            # outlook filter rule
            # forward outlook rule, calendar, ... (as if from internal to another internal)

            # More possible dangerous file types to test out in the future: http://en.wikipedia.org/wiki/User:Ruud_Koot/Dangerous_file_types
            # this one is really cool, reversing the name: http://www.howtogeek.com/127154/how-hackers-can-disguise-malicious-programs-with-fake-file-extensions/
        except Exception as e:
            print("email filter class 161 except: " + str(e) + " Error on line {}".format(sys.exc_info()[-1].tb_lineno))

    def email_identification(self) -> None:
        """Email identification used for identification on forwarded back email to correctly assign to right test in DB
        """
        try:
            # reset counter for each email to send out
            self.counter450 = 0
            self.counter421 = 0

            self.encrypted_server_info = f"\n\n EmailTest#:{self.email_server};{self.port};{self.test_num};{self.start_time};{self.domain};main\
                                        \nRandomization String: {self.identification_code}\n"

        except Exception as e:
            print("email filter class 172 except: " + str(e) + " Error on line {}".format(sys.exc_info()[-1].tb_lineno))

    # send out the email
    def sending_email(self, email_from, email_to, message, email_filter_output, data_from, data_to,
                      read_receipt_to=None, attachment=None, bywayof=None, onbehalfof=None) -> None:
        """Send out the email

        Args:
            email_from (Any): Email from
            email_to (Any): Email to
            message (Any): The email message
            email_filter_output (Any): Output file to write to
            data_from (Any): Data from
            data_to (Any): Data to
            read_receipt_to (Any, optional): Read receipt to. Defaults to None.
            attachment (Any, optional): Attachment. Defaults to None.
            bywayof (Any, optional): By Way Of address. Defaults to None.
            onbehalfof (Any, optional): On Behalf Of address. Defaults to None.
        """
    
        try:
            #print('Sending ' + str(self.test_num) + ' through ' + self.email_server)
            if not self.bad_receipient:
                # Not sure why '\' added before '-' automatically so removing it ;)
                if "-" in email_to and "\\" in email_to:
                    email_to = email_to.replace("\\", "")

                
                # create_path(individual_email_logs_path, self.debug)
                # individual_email_file = f"{individual_email_logs_path}{email_to[0]}_{str(self.start_time).replace(':', '').replace(' ', '')}.txt"
                # with open(individual_email_file, "w") as email_filter_output_to:
                #     email_filter_output_to.write(message)

                message_for_log = message.replace("\n", "<br>").replace("\t", " ").replace('"', "'")
                # strip off base64 encoded attachments
                if "Content-Disposition: attachment; filename='" in message_for_log:
                    file_name_pos = message_for_log.find("Content-Disposition: attachment; filename='") + 43
                    tmp = message_for_log[43:]
                    end_file_name_pos = tmp.find("'")
                    message_for_log = message_for_log[:file_name_pos + end_file_name_pos]

                t = None
                available_fd = None
                # if self.test_num == "10":
                # Capture output (replies) to verify commands external email server supports
                # get available file descriptor
                t = tempfile.TemporaryFile()
                available_fd = t.fileno()
                t.close()
                # make copy of stdout
                os.dup2(2, available_fd)
                # create new tempfile and direct pythons stdout there
                t = tempfile.TemporaryFile()
                os.dup2(t.fileno(), 2)
                
                title_test_num = self.test_num
                # it title_test_num is a float string then remove the decimal and turn into an int
                if "." in title_test_num:
                    title_test_num = title_test_num[:title_test_num.find(".")]
                # set the test number for the filename of the email file created in createEML if the test number is in the list of tests that could repeat
                if int(title_test_num) in self.tests_that_could_repeat:
                    try:
                        test_count_var = getattr(self, f"test_{title_test_num}_count")
                    except AttributeError:
                        test_count_var = 0
                        print_error(f"Error: test_{str(self.test_num)}_count not found. Setting to 0.")
                    title_test_num = f"{int(title_test_num)}.{test_count_var}"
                    setattr(self, f"test_{str(self.test_num)}_count", test_count_var + 1)

                
                if self.port == "465":  # then use SMTP_SSL
                    try:
                        smtp = smtplib.SMTP_SSL(self.email_server, int(self.port))
                        smtp.set_debuglevel(5)
                        smtp.ehlo(self.smtp_ehlo_server)
                        smtp.login(self.smtp_username, self.smtp_passwd)
                        smtp.sendmail(email_from, email_to, message)
                        smtp.quit()
                        print_msg("Successfully sent Test " + self.test_num + " to " + self.email_server + ".")
                    except Exception as e:
                        print_error("Error: unable to send email Test " + self.test_num + " to " + self.email_server + ".  " + str(e))
                        if "smtprecipientsrefused" in str(e).lower():
                            self.bad_receipient = True
                        else:
                            # try to resend the email after waiting 15 seconds
                            if ("450" in str(e) or "451" in str(e)) and self.counter450 < 3:
                                print("emailfilter retrying " + str(self.test_num) + " because got a " + str(e) + " back which typically means we need to resend in order to get it delivered.")
                                self.counter450 += 1
                                time.sleep(self.counter450 * 350)
                                self.sending_email(email_from, email_to, message, email_filter_output,
                                                   data_from, data_to, read_receipt_to, attachment)
                            elif ("450" in str(e) or "451" in str(e)) and self.count450 >= 3:
                                self.counter450 = 0
                            if "421" in str(e) and self.counter421 < 3:
                                # try to resend but wait longer time between b/c probably being rate limited
                                if self.pause_time < 3600:
                                    self.pause_time = self.pause_time * 2
                                    time.sleep(self.counter421 * self.pause_time)
                                else:
                                    time.sleep(self.counter421 * 421)
                                self.counter421 += 1
                                self.sending_email(email_from, email_to, message, email_filter_output,
                                                   data_from, data_to, read_receipt_to, attachment)
                            elif "421" in str(e) and self.counter421 >= 3:
                                self.counter421 = 0
                else:
                    try:
                        smtp = smtplib.SMTP(self.email_server, int(self.port))
                        smtp.set_debuglevel(5)
                        smtp.ehlo(self.smtp_ehlo_server)
                        smtp.sendmail(email_from, email_to, message)
                        smtp.quit()
                        print_msg("Successfully sent Test " + title_test_num + " to " + self.email_server + ".")
                    except Exception as e:
                        print_error("Error: unable to send email Test " + title_test_num + " to " + self.email_server + ".  " + str(e))

                        if "smtprecipientsrefused" in str(e).lower():
                            self.bad_receipient = True
                        else:
                            # try to resend the email after waiting 15 seconds
                            if ("450" in str(e) or "451" in str(e)) and self.counter450 < 3:
                                print("Retrying Test" + str(self.test_num) + " because got a " + str(e) + " back which typically means we need to resend in order to get it delivered.")
                                self.counter450 += 1
                                time.sleep(self.counter450 * 350)
                                self.sending_email(email_from, email_to, message, email_filter_output,
                                                   data_from, data_to, read_receipt_to, attachment)
                            elif ("450" in str(e) or "451" in str(e)) and self.count450 >= 3:
                                self.counter450 = 0   
                            if "421" in str(e) and self.counter421 > 3:
                                # try to resend but wait longer time between b/c probably being rate limited
                                if self.pause_time < 3600:
                                    self.pause_time = self.pause_time * 2
                                    time.sleep(self.counter421 * 421)
                                    self.sending_email(email_from, email_to, message, email_filter_output,
                                                       data_from, data_to, read_receipt_to, attachment)
                                    self.counter421 += 1

                if t is not None and available_fd is not None:
                    # grab stdout from temp file
                    sys.stderr.flush()
                    t.flush()
                    t.seek(0)
                    stderr_output = t.read()
                    t.close()
                    # put back stderr
                    os.dup2(available_fd, 2)
                    os.close(available_fd)
                    
                    smtp_logs_path = os.path.join(os.path.abspath(self.output_folder), 'smtp_logs/')
                    create_path(smtp_logs_path, self.debug)
                    individual_email_logs_path = os.path.join(os.path.abspath(smtp_logs_path), self.email_server)
                    create_path(individual_email_logs_path, self.debug)
                    # FIXME: check if the test number is in the list of tests that could repeat and if it is make a new file for each test
                    individual_email_path_out_file = os.path.join(individual_email_logs_path, f'{self.email_server}_test#{title_test_num}.txt')
                    with open(individual_email_path_out_file, 'w') as iepof:
                        iepof.write(stderr_output.decode('utf-8'))
                        
                    
                    # JSON Output for inserting into engage
                    email_headers = {
                        "port": self.port,
                        "testnum": self.test_num,
                        "emailserver" : self.email_server,
                        "smtpfrom": email_from,
                        "smtpto": email_to,
                        "datafrom": data_from,
                        "datato": data_to,
                        "attachment": attachment,
                        "bywayof": bywayof,
                        "onbehalfof": onbehalfof,
                        "readreceipt": read_receipt_to,
                        "id": self.identification_code
                    }
                    json_email_headers = json.dumps(email_headers)

                    json_individual_email_logs_file = os.path.join(individual_email_logs_path, f'{self.email_server}_test#{title_test_num}.json')
                    
                    with open(json_individual_email_logs_file, "w") as eout:
                        eout.write(json_email_headers)
                    
                    # create logging email files that show exactly what was sent to the email server
                    self.create_eml(title_test_num, message)
                        
            else:
                print_error("Error: unable to send email Test " + self.test_num + " to " + self.email_server + ".  Bad receipient.")
        except Exception as e:
            print_error("Error: " + str(e) + " Error on line {}".format(sys.exc_info()[-1].tb_lineno))

def parseNumList(list_string: str):
    m = match(r'(\d+)(?:-(\d+))?$', list_string)
    number_list = list_string.split(' ')
    if not m:
        if not number_list:
            raise ArgumentTypeError("'" + list_string + "' is not a range of number. Expected forms like '0-5' or '2'.")
        return number_list
    start = m.group(1)
    end = m.group(2) or start
    return list(range(int(start,10), int(end,10)+1))

def main():
    # if the user is using an unsupported version of the application, then exit
    
    
    parser = ArgumentParser(description='Email Filter Testing')
    parser.add_argument('-v', '--version', action='version', version=__version__)
    parser.add_argument('-e', '--email_server_file',
                        help='File containing list of email gateways to test (MX records, etc). \
                            If ommitted, will attempt to use Microsoft MX record for client domain specified in the -to flag', type=str)
    parser.add_argument('-t', '--number_of_seconds_delay',
                        help='Number of seconds to delay between each test, typically should be > 200 (default is 201)', type=int, default=201)
    parser.add_argument('-a', '--attachments_folder', help='Path to folder containing attachments. Defaults to /pentest2022/email-relay/advanced/email_attachments', default='/pentest2022/email-relay/advanced/email_attachments', type=str)
    parser.add_argument('-o', '--output_dir', help='Directory to save output files (smtp logs, .json logs, .eml files) Defaults to results', default='results', type=str)
    parser.add_argument('--subject', help='Custom subject line for emails. Defaults to "Testing Mail Relay TESTNUM through EMAILSERVER. Forward to FORWARDTOEMAIL!"', type=str)
    # parser.add_argument('-rr', '--email_for_read_receipt',
    #                     help='email address where read receipts will be sent (typically your issg email)')
    # list of email tests to run as a list of integers
    parser.add_argument('-et', '--email_tests', help='List of specific email tests to run as a list of integers (Ex.: 1 4 10 8 7)', nargs='+', type=int)
    parser.add_argument('--debug', help=SUPPRESS, action='store_true')
    requiredNamed = parser.add_argument_group('required named arguments')
    requiredNamed.add_argument('-s', '--sub_domain_file', help='File containing a list of sub-domains of client domain (Example: vpn.example.com)', required=True)
    requiredNamed.add_argument('-to', '--client_email_address',
                        help='Email address to send these test email filter messages to', required=True, type=str)
    requiredNamed.add_argument('-id', '--external_identification', help='External Identification number', required=True, type=str)
    args = parser.parse_args()
    
    

    # if the folder exists and is not empty assign it to the attachments_folder variable
    attachments_folder = args.attachments_folder if os.path.isdir(args.attachments_folder) and len(os.listdir(args.attachments_folder)) > 0 else None
    # if email tests are not attachment related tests then continue
    if attachments_folder is None and args.email_tests is not None and len(args.email_tests) > 0 and (any(test in args.email_tests for test in ATTACHMENT_TESTS)):
        print_error(f'Error: Attachments folder: "{args.attachments_folder}" does not exist or is empty.  Please provide a valid attachments folder so that attachment tests can be run.')
        return
    elif attachments_folder is None and args.email_tests is None:
        print_error(f'Error: Attachments folder: "{args.attachments_folder}" does not exist or is empty.  Please provide a valid attachments folder so that attachment tests can be run.')
        return
    output_directory_path = args.output_dir
    email_server_file = args.email_server_file if args.email_server_file is not None else ''
    sub_domain_records = args.sub_domain_file
    email_to = args.client_email_address
    emailfilter_pause_time = int(args.number_of_seconds_delay)
    # if we are debugging, then remove the check for the emailfilter_pause_time
    if not args.debug:
        if emailfilter_pause_time < 201:
            random_num = random.randint(201, 384)
            print_bold('You only selected a delay of ' + str(
                emailfilter_pause_time) + ". Typically this should be above 200 and therefore, it is being adjusted automatically to " + str(
                random_num) + ".")
            emailfilter_pause_time = random_num
    identification_code = args.external_identification
    send_read_receipt_to = None
    email_relay_servers_to_bounce_emails_from = ''  # 'relay.mail.cogentco.com' # multiple separated by ';'
    username = ''
    passwd = ''

    if create_path(output_directory_path, args.debug):

        email_filter_values = {'email_to': email_to, 'emailfilter_pause_time': emailfilter_pause_time,
                               'identification_code': identification_code, 'send_read_receipt_to': send_read_receipt_to,
                               'email_relay_servers_to_bounce_emails_from': email_relay_servers_to_bounce_emails_from,
                               'invalid_user_name': INVALID_USER_NAME,
                               'smtp_ehlo_server': SMTP_EHLO_SERVER,
                               'spoof_domain_no_spf_dmarc_dkim': SPOOF_DOMAIN_NO_SPF_DMARC_DKIM,
                               'spoof_domain_with_spf_hardfail': SPOOF_DOMAIN_WITH_SPF_HARDFAIL,
                               'spoof_domain_with_spf_softfail': SPOOF_DOMAIN_WITH_SPF_SOFTFAIL,
                               'num_invalid_domains_to_try': NUM_INVALID_DOMAINS_TO_TRY,
                               'email_msg_where_to_forward_back_to': EMAIL_MSG_WHERE_TO_FORWARD_BACK_TO,
                               'testers_domain': TESTERS_DOMAIN, 'public_ip': PUBLIC_IP, 'your_ip_address': YOUR_IP_ADDRESS,
                               'username': username, 'passwd': passwd}

        emailservers = []
        
        sub_dns_records = []
        # if the sub domain file exists, read in the sub domains
        if os.path.isfile(sub_domain_records):
            with open(sub_domain_records, 'r') as sdr:
                subdomains = sdr.readlines()
                # if there are no sub domains in the file, print an error and return
                if len(subdomains) == 0:
                    print_error(f"Error: Sub domain file: {sub_domain_records} is empty.  Please provide a valid sub domain file.")
                    return
                for sd in subdomains:
                    if sd.strip() != "":
                        sub_dns_records.append(sd.strip())
        else:
            print_error(f"Error: Sub domain file: {sub_domain_records} does not exist.  Please provide a valid sub domain file.")
            return
                        
        # if an email server file is provided, use that, otherwise, use the default microsoft mail server
        if email_server_file is not None and email_server_file != "":
            if os.path.isfile(email_server_file):
                with open(email_server_file, 'r') as esf:
                    es = esf.readlines()
                    for e in es:
                        if e.strip() != "":
                            emailservers.append(e.strip())
            else:
                print_error("Email server file does not exist.  Please provide a valid email server file.")
                return


            if len(emailservers) > 0 and len(sub_dns_records) > 0:
                for email_server in emailservers:
                    port = 25
                    if ":" in email_server:
                        port = email_server[email_server.find(":") + 1:]
                        email_server = email_server[:email_server.find(":")]
                    with EmailFilter(output_directory_path, email_server, port, email_filter_values, sub_dns_records, attachments_folder, args.debug, args.email_tests) as email_filter:
                        if args.subject is not None and args.subject != "":
                            email_filter.change_subject(args.subject)
                        email_filter.mail_relay()
                        
        domain = email_to[email_to.find("@") + 1:]  # email_filter_values['client_domain']

        # look for MX record for current domain
        try:
            # get txt record
            microsoft_mx = None
            txts = dns.resolver.resolve(domain, 'TXT')
            for txt in txts:
                # print("4502 emailfilter txt: " + str(txt))
                txt = str(txt)
                # add microsoft mx record if it exists
                if "office" in txt.lower() or "microsoft" in txt.lower() or "outlook" in txt.lower() or "ms=" in txt.lower():
                    microsoft_mx = domain.replace(".", "-") + ".mail.protection.outlook.com"
                    # FIXME: Check that the microsoft_mx resolves to a valid IP address, if not, set it to None, otherwise, it will be tested 
                    
        except Exception as e:
            print("Error with grabbing Microsoft MX: " + str(e))
        # if the microsoft mx record exists and it is NOT already in the emailservers list, test it
        if microsoft_mx is not None and microsoft_mx not in emailservers:
            port = 25
            with EmailFilter(output_directory_path, microsoft_mx, port, email_filter_values, sub_dns_records, attachments_folder, args.debug, args.email_tests) as email_filter:
                if args.subject is not None and args.subject != "":
                    email_filter.change_subject(args.subject)
                email_filter.mail_relay()
            return
        # if there is no microsoft mx record and no email servers in the email server file, print error
        if len(emailservers) == 0 and microsoft_mx is None:
            print_error("Error: No email servers found in the email server file you provided and no Microsoft MX record found for the domain you provided.")
            print_error("Error: Please provide a file containing a list of email servers to test or provide a domain that has a Microsoft MX record.")
    else:
        return

if __name__ == '__main__':
    main()
