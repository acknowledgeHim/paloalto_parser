#!/usr/bin/env bash
# use the host command to get the mail servers from a file with a list of domains or a single domain

# usage: get-mailservers.sh <file with list of domains | domain>

# example: get-mailservers.sh domains.txt
# example: get-mailservers.sh domain.com

# output: <domain>: 
#<mail server> 
#<mail server> ...

GREEN='\033[0;32m'
ENDC='\033[0m'
RED='\033[0;31m'
CYAN='\033[0;36m'
PURPLE='\033[0;35m'

all_mail_servers=()

get_mail_servers() {
    # get the mail servers and if $NF is record, then the domain does not exist
    domain_mailservers=($(host -t mx $1 | awk '{print $NF}'))
    if [ "${domain_mailservers[0]}" == "record" ]; then
        echo -e "${RED}Error:${ENDC} No MX records for ${RED}$1${ENDC}"
        return
    fi
    # print the domain and the mail servers
    echo -n -e "${GREEN}Success: $1:${ENDC}"
    for mailserver in "${domain_mailservers[@]}"; do
        # remove the trailing dot
        mailserver=${mailserver%.}
        all_mail_servers+=($mailserver)
        echo -n " $mailserver"
    done
    echo
}

usage()
{
    echo -e "${PURPLE}Usage:${ENDC} $0 <file with list of domains | domain>"
    echo -e "${PURPLE}Example:${ENDC} $0 domains.txt"
    echo "A file with all mail servers will be created in the current directory"
    echo "Running this script multiple times will append to the file"
    exit 1
}

# check if the file or domain is provided
if [ -z "$1" ]; then
    echo -e "${RED}Error:${ENDC} Please provide a file with a list of domains or a single domain \n"
    usage
fi

# check if the file exists or if the domain is valid
if [ -f "$1" ]; then
    echo -e "File ${GREEN}$1${ENDC} exists"
    # loop through the file
    while read domain; do
        get_mail_servers $domain
    done < $1
elif host -t mx $1 &> /dev/null; then
    echo -e "Domain ${GREEN}$1${ENDC} is a valid domain"
    get_mail_servers $1
else
    echo -e "${RED}Error:${ENDC} File $1 does not exist and $1 is not a valid domain\n"
    usage
fi

# write the domain_mailservers array to a file if the entry is not "record"
for mailserver in "${all_mail_servers[@]}"; do
    if [ "$mailserver" != "record" ]; then
        echo $mailserver >> mailservers.txt
    fi
done

# remove duplicates
sort -u mailservers.txt -o mailservers.txt

echo -e "${CYAN}All mail servers written to mailservers.txt${ENDC}"