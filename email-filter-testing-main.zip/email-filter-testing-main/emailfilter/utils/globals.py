import urllib.request

LINUX_GROUP = 'issg'
INVALID_USER_NAME = 'clawasneverhere'
SPOOF_DOMAIN_NO_SPF_DMARC_DKIM = 'emailfiltertest.com' # Ideally is a domain that has no SPF, DMARC, or DKIM records and is rarely used
SPOOF_DOMAIN_WITH_SPF_HARDFAIL = 'microsoft.com'
SPOOF_DOMAIN_WITH_SPF_SOFTFAIL = 'symantec.com'
NUM_INVALID_DOMAINS_TO_TRY = '5'
EMAIL_MSG_WHERE_TO_FORWARD_BACK_TO = 'relay@issgs.net'
TESTERS_DOMAIN = 'issgs.net'
PUBLIC_IP = '68.168.173.143'
PRIVATE_IP = '192.168.0.12'
YOUR_IP_ADDRESS = urllib.request.urlopen('https://ident.me').read().decode('utf8')
SMTP_EHLO_SERVER = 'scanner1.issgs.net'
VALID_MAIL_SERVER = 'mail.issgs.net'
CUSTOM_SUBJECT = ''
#custom_subject = 'CLA Filter Testing: TESTNUM through EMAILSERVER'  #REPLACEWORDS: TESTNUM, EMAILSERVER, FORWARDTOEMAIL
ATTACHMENT_TESTS = [12, 13, 14, 15, 16, 18, 19, 22, 23, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43]
REPEATABLE_TESTS = [6, 9, 57, 59, 64, 65, 66, 67, 73]
SENDING_ORDER = [9, 20, 10, 5, 6, 73, 7, 8, 17, 24, 26, 27, 28, 44, 45, 46, 47, 48, 49, 50, 51, 52, 54, 55, 56, 57, 58, 59, 60, 61, 62, 72, 74, 41, 42, 43, 16, 18, 19, 
                22, 23, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 63, 64, 65, 66, 67, 68, 69, 70, 71, 39, 40, 12, 13, 14, 15, 11, 3, 4] # then 1, 2, 0
