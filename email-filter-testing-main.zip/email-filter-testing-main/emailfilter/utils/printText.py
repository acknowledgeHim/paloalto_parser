class bcolors:
    """
    Description: Print text with color and style.
    """
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'  # yellow
    OKPURPLE = '\033[95m'
    OKCYAN = '\033[96m'
    ORANGE = '\033[208m'
    FAIL = '\033[91m'  # red
    ENDC = '\033[0m'  # clear
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    ITALIC = '\033[3m'
    STRIKETHROUGH = '\033[9m'
    FLASHING = '\033[6m'

def print_underline(line: str) -> None:
    print(bcolors.UNDERLINE + str(line) + bcolors.ENDC)

def print_italic(line: str) -> None:
    print(bcolors.ITALIC + str(line) + bcolors.ENDC)

def print_result_begin(line: str) -> None:
    print(bcolors.OKGREEN + str(line))

def print_result(line: str) -> None:
    print(bcolors.OKGREEN + str(line) + bcolors.ENDC)

def print_msg(line: str) -> None:
    print(bcolors.OKBLUE + str(line) + bcolors.ENDC)

def print_bold(line: str) -> None:
    print(bcolors.BOLD + str(line) + bcolors.ENDC)

def print_quote(line: str) -> None:
    print(bcolors.OKCYAN + str(line) + bcolors.ENDC)

def print_warning(line: str) -> None:
    print(bcolors.WARNING + str(line) + bcolors.ENDC)

def print_error(line: str) -> None:
    print(bcolors.FAIL + str(line) + bcolors.ENDC)

def print_close(line: str) -> None:
    print(line + bcolors.ENDC)
