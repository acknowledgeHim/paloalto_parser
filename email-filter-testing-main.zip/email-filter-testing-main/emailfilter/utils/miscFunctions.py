import os
import pwd
import grp
import getpass
from typing import TYPE_CHECKING
from email.mime.multipart import MIMEMultipart


from emailfilter.utils.printText import print_error
from emailfilter.utils.globals import LINUX_GROUP

def get_tester() -> str:
    """Gets the current user.
    
    Returns:
        str: Returns the current logged on user
    """
    return getpass.getuser()

def assign_permissions(path_to_assign: str, debug: bool = False) -> bool:
    """Assigns permissions to the path_to_assign folder.

    Args:
        path_to_assign (str): The path to assign permissions to.
        debug (bool, optional): If True, debugging is enabled. Defaults to False.

    Returns:
        bool: True if successful, False otherwise.
    """
    # If we are debugging, we don't need to assign permissions
    if debug:
        return True
    try:
        uid = pwd.getpwnam(get_tester()).pw_uid
        gid = grp.getgrnam(LINUX_GROUP).gr_gid
        os.chown(path_to_assign, uid, gid)
    except Exception as e:
        print_error(f"Error: Assign permissions: The '{LINUX_GROUP}' value is not a valid group on your computer.  Please correct this before trying again.")
        return False
    try:
        os.chmod(path_to_assign, 0o774)
        return True
    except Exception as e:
        print_error(f"Error: Assign permissions: The '{path_to_assign}' folder could not be assigned permissions.  Please correct this before trying again.")
        return False

def create_path(path_to_create : str, debug: bool = False) -> bool:
    """
    Creates necessary folder structure for client/engagement.
    
    Args:
        path_to_create: The path to create.
        debug: If True, debugging is enabled. Defaults to False.
        
    Returns:
        bool: True if successful, False otherwise.
    """
    try:
        os.makedirs(path_to_create, 0o774)
    except Exception as e:
        if "file exists" not in str(e).lower():
            print_error(f"Error: Failed making the new folder '{path_to_create}', except: {str(e)}")
    """
    if "/output/" in path_to_create:
        output_location = path_to_create.find("/output/") + 8
        output_path = path_to_create[:output_location]
        for root, dirs, files in os.walk(output_path):
            for d in dirs:
                assign_permissions(os.path.join(root,d))
            for f in files:
                file_path = os.path.join(root, f)
                assign_permissions(file_path)
    """
    return True

def add_headers(message: str, email_from: str, email_to: list[str], data_from: str, data_to: str, attachment: str, bywayof: str, onbehalfof: str, read_receipt_to: str) -> str:
    """Adds headers to the message.

    Args:
        message (str): The message to add headers to.
        email_from (str): The email address of the sender.
        email_to (list[str]): The email address of the recipients.
        data_from (str): The data source of the sender.
        data_to (str): The data source of the recipient.
        attachment (str): The attachment.
        bywayof (str): The method of delivery.
        onbehalfof (str): The person the message is on behalf of.
        read_receipt_to (str): The email address to send read receipts to.

    Returns:
        str: The message with headers added to the body.
    """
    if "</body>" in message.lower():
        headers = f"\n\n<div style='font-size:1px'>\n\nsmtpfrom:{email_from}\nsmtpto:{[str(x) for x in email_to]}\ndatafrom:{data_from}\n\
datato:{data_to}\nattachment:{str(attachment)}\nbywayof:{str(bywayof)}\nonbehalfof:{str(onbehalfof)}\nreadreceipt:{str(read_receipt_to)}\n--------EOM------\n</div>"

        message = message.replace("</body>", headers + "</body>")
    else:
        print_error("Error: The message does not contain a body tag.  No headers will be added to the end of the message.")
    return message

def send_individual_email(emailFilter, msgRoot: MIMEMultipart, email_from: str, email_to: str, email_filter_output: str, attachment_type: str=None) -> None:
    """Sends an individual email using the EmailFilter class with the msgRoot object.

    Args:
        emailFilter (EmailFilter): The EmailFilter class.
        msgRoot (MIMEMultipart): The MIMEMultipart email object.
        email_from (str): SMTP from.
        email_to (str): SMTP to.
        email_filter_output (str): The output folder.
        attachment_type (str, optional): The attachment identifier. Defaults to None.
    """
    
    message = msgRoot.as_string()
    data_from = msgRoot['From']
    data_to = msgRoot['To']
    attachment = attachment_type
    read_receipt_to = msgRoot['Disposition-Notification-To'] if msgRoot['Disposition-Notification-To'] else None
    bywayof = msgRoot['Resent-By'] if msgRoot['Resent-By'] else None
    onbehalfof = msgRoot['Sender'] if msgRoot['Sender'] else None
        

    # send out the email
    emailFilter.sending_email(email_from, email_to, message, email_filter_output, data_from,
                        data_to, read_receipt_to, attachment, bywayof, onbehalfof)