import ipaddress
import socket
import whois

def private_ip(ip:str) -> bool:
    """Returns True if the IP is private (either IPv4 or IPv6)
    
    Arguments:
        ip (str): IP address to check if private
        
    Returns:
        bool: True if private, False if not private
    """
    
    return ipaddress.ip_address(ip).is_private

def valid_ip(address: str) -> bool:
    """
    Checks for valid IPv4 or IPv6 Address
    Makes sure the IP address given is a valid IPv4 address. If it isn't, it
    will then make a similar check if it is a valid IPv6 address. The
    checks are done in separate functions.

    Arguments:
        address (str): String to check if valid IPv4 or IPv6 Address
    Returns:
        bool: True if it is a valid IPv4 or IPv6 address.
    """

    if address is not None:
        validip = is_valid_ipv4_address(address)
        if not validip:
            validip = is_valid_ipv6_address(address)
        return validip
    return False

def is_valid_ipv4_address(address: str) -> bool:
    """
    Checks for valid IPv4 Address
    Verifies if the string is a valid IPv4 address.

    Arguments:
        address (str): String to check if valid IPv4 Address
        
    Returns:
        bool: True if it is a valid IPv4 address.
    """

    try:
        socket.inet_pton(socket.AF_INET, address)
    except AttributeError:  # no inet_pton here, sorry
        try:
            socket.inet_aton(address)
        except socket.error:
            return False
        return address.count('.') == 3
    except socket.error:  # not a valid address
        return False
    return True

def is_valid_ipv6_address(address: str) -> bool:
    """
    Checks for valid IPv6 Address
    Verifies if the string is a valid IPv6 address.

    Arguments:
        address (str): String to check if valid IPv6 Address
        
    Returns:
        bool: True if it is a valid IPv6 address.
    """

    try:
        socket.inet_pton(socket.AF_INET6, address)
    except socket.error:  # not a valid address
        return False
    return True

def has_whois(domain: str) -> bool:
    """
    Checks for whois information
    Verifies if the domain has whois information.

    Arguments:
        domain (str): Domain to check if it has whois information
        
    Returns:
        bool: True if it has whois information.
    """

    try:
        w = whois.whois(domain)
        return True
    except Exception as e:
        return False