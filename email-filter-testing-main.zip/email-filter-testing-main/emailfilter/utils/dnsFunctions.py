import socket
import sys
import time
from ipwhois import IPWhois
import dns.resolver
from dns.resolver import Answer

from emailfilter.utils.networkFunctions import private_ip, valid_ip
from emailfilter.utils.printText import print_error

def get_full_hostname_of_local_computer() -> str:
    """ Return your computer's fully qualified domain name.
    
    Returns:
        str: Your computer's fully qualified domain name.
    """
    return socket.getfqdn()

def find_dns_records(domain : str) -> str:
    """ Get A record DNS entries.
    
    Args:
        domain (str): The domain to get the IP address for.
        
    Returns:
        str: The IP address for the domain or an empty string if no IP address is found.
    """
    try:
        answer: Answer = dns.resolver.resolve(domain, "A")
        for data in answer:
            return data.address
        print(answer.address)
    except:
        return ""

def grab_dns_record(domain: str, public_only:bool = True) -> tuple[str, str]:
    """Get the IP address and additional information for a domain.

    Args:
        domain (str): The domain to get the IP address and additional information for.
        public_only (bool, optional): Only return public IP addresses. Defaults to True.

    Returns:
        tuple[str, str]: The IP address and additional information for the domain.
    """
    try:
        domain_ip = find_dns_records(domain)
        if isinstance(domain_ip, str) and domain_ip != "":
            domain_ip.encode("utf-8")
        if domain_ip != "" and valid_ip(domain_ip) and not private_ip(domain_ip) and public_only:
            additional = "DNS A Record: " + domain_ip + "; " + grab_whois_ip(domain_ip)
            sep = ""
            if additional != "":
                sep = "; "
        else:
            #print_error("\tThe domain entered, " + domain + ", does not have a valid IP address it resolves to, so this might be an unused domain!")
            additional = "Domain has no associated IP."
            domain_ip = ""
    except Exception as e:
        print_error("dns_functions 105 except: " + str(e) + " Error on line {}".format(sys.exc_info()[-1].tb_lineno))
        domain_ip = ""
        additional = ""
    return domain_ip, additional

def grab_whois_ip(ip: str) -> str:
    """
    Does whois search and puts results in information(str).
    If get connection reset by peer then sleep for 90 sec and try again.

    Arguments:
        ip (str): single IP address used to find Whois and Geolocation information
        
    Returns:
        str: Whois and Geolocation information for the IP address
    """
    whois_info = []
    information = ''
    text_divider = "; "
    try:
        ipwhoisobj = IPWhois(ip)
        whois_info = ipwhoisobj.lookup_whois(get_referral=True)
    except Exception as e:
        #print("dns_functions 174 except: " + str(e) + " Error on line {}".format(sys.exc_info()[-1].tb_lineno))
        if "connection reset by peer" in str(e).lower():
            time.sleep(90)
        try:
            ipwhoisobj = IPWhois(ip)
            whois_info = ipwhoisobj.lookup_whois(get_referral=True)
        except Exception as e:
            print_error("\tWhois lookup failed for " + ip + ".")#, except: " + str(e) + " Error on line {}".format(sys.exc_info()[-1].tb_lineno))
    try:
        if len(whois_info) > 0:
            if 'nets' in whois_info:
                networks = whois_info['nets']
                if 'name' in whois_info['nets'][0] and 'cidr' in whois_info['nets'][0]:
                    isp = "ISP: " + whois_info['nets'][0]['name'] + " for IP range " + whois_info['nets'][0]['cidr']
                    if isp not in information:
                        sep = ''
                        if information != "":
                            sep = text_divider
                        information = information + sep + isp
                sep = ''
                for network in networks:
                    if 'description' in network:
                        if information != '':
                            sep = text_divider
                        if network is not None and 'description' in network and information is not None and (isinstance(network['description'], str) and network['description'] not in information):  # avoid having redudant descriptions added
                            information = network['description'] + sep + information
            if 'referral' in whois_info:
                referral = whois_info['referral']
                if referral is not None and 'description' in referral:
                    if referral['description'].strip() != "" and referral['description'] not in information:
                        sep = ''
                        if information != "":
                            sep = text_divider
                        information = referral['description'] + sep + information
                if referral is not None and 'name' in referral:
                    if referral['name'].strip() != "" and referral['name'] not in information:
                        sep = ''
                        if information != "":
                            sep = text_divider
                        information = referral['name'] + sep + information
    except Exception as e:
        print("dns_functions 4006 except: " + str(e) + " Error on line {}".format(sys.exc_info()[-1].tb_lineno))
    return information.replace("\n", "; ").replace("\t", "")
