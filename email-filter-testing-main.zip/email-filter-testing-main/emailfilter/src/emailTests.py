from __future__ import annotations
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.base import MIMEBase
from email.utils import COMMASPACE, formatdate, make_msgid
from typing import TYPE_CHECKING
from email import encoders
import dns.resolver
import sys
import os
import string
import random
import socket
import base64
import string

from utils.dnsFunctions import get_full_hostname_of_local_computer, find_dns_records
from utils.networkFunctions import valid_ip, private_ip, has_whois
from utils.printText import print_msg, print_error
from utils.cleanText import replace_wording
from utils.miscFunctions import send_individual_email

if TYPE_CHECKING:
    from src.emailfilter import EmailFilter


# client should receive this otherwise they are blacklisting you
def test0(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Client should receive this otherwise they are blacklisting you

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    try:
        print_msg('Sending test0, which is a valid email and used to help verify if we are just being blacklisted, so the client SHOULD always receive this email.')
        emailFilter.test_num = str(emailFilter.test_num_prefix + 0)

        # create the encrypted email identification text at bottom of every email
        emailFilter.email_identification()

        bodytext = "This is a mail relay test " + emailFilter.test_num + ", and represents a valid email from ISSG's IP range through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        email_from = emailFilter.forward_email_to
        email_to = [emailFilter.client_email]
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)
        # We reference the image in the IMG SRC attribute by the ID we give it below
        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
        
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                        msgRoot['To'], msgRoot['Disposition-Notification-To'])
    except Exception as e:
        print("email filter class 244 except: " + str(e) + " Error on line {}".format(sys.exc_info()[-1].tb_lineno))

# open relay
def test1(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Open relay

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 1)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an external address to an external address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)

    email_from = 'notification@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.forward_email_to]
    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.forward_email_to
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)
    # We reference the image in the IMG SRC attribute by the ID we give it below
    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)

    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# half open relay
def test2(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Half open relay

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 2)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an internal address to an external address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)

    email_from = emailFilter.client_email
    email_to = [emailFilter.forward_email_to]  # [emailFilter.forward_email_to]

    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = emailFilter.client_email
    msgRoot['To'] = emailFilter.forward_email_to
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)
    # We reference the image in the IMG SRC attribute by the ID we give it below
    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# valid internal spoof
def test3(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Valid internal spoof
    
        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to  

    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 3)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an internal address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
    email_from = emailFilter.client_email
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = emailFilter.client_email
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)
    # We reference the image in the IMG SRC attribute by the ID we give it below
    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# invalid internal spoof
def test4(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Invalid internal spoof
    
        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 4)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an invalid internal address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
    email_from = 'clawasneverhere@' + emailFilter.domain
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = 'clawasneverhere@' + emailFilter.domain
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)
    # We reference the image in the IMG SRC attribute by the ID we give it below
    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# spoof tld
def test5(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Spoof tld
    
        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to    

    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 5)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    client_username = emailFilter.client_email[:emailFilter.client_email.find("@") + 1]
    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed address with an invalid top level domain to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)

    tld = emailFilter.domain[emailFilter.domain.rfind("."):]
    dm = emailFilter.domain[:emailFilter.domain.rfind(".")]
    spoof_domain = dm + tld[:-1] + "0"  # replaces last character of tld w/ z (ie. google.com would be google.co0)
    if "com" in tld:
        spoof_domain = dm + tld.replace("com", "c0m")
    elif "net" in tld:
        spoof_domain = dm + tld.replace("net", "n3t")
    elif "us" in tld:
        spoof_domain = dm + tld.replace("us", "7s")
    elif "org" in tld:
        spoof_domain = dm + tld.replace("org", "0rg")
    email_from = client_username + spoof_domain
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)
    # We reference the image in the IMG SRC attribute by the ID we give it below
    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
    
    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# spoof domain
def test6(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Spoof domain

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 6)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()
    client_username = emailFilter.client_email[:emailFilter.client_email.find("@") + 1]
    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an email address with a spoofed domain name to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)

    dm = emailFilter.domain[:emailFilter.domain.rfind(".")]  # ie google
    tld = emailFilter.domain[emailFilter.domain.rfind("."):]  # ie .com
    spoof_domain = None
    already_tried_spoof_domain = []
    repetition = 0
    while repetition < emailFilter.repeat:
        stillvalid = True  # make sure found a unregistered domain - will only send test 6 if stillvalid is False
        count_iterations = 0  # make sure we break out of this madness at some point !
        registered_domain_no_spf_sent = 0  # used to keep track of # of times registered domain found w/ no SPF and test 9 sent using it
        while True or count_iterations > 200:
            # Trying to find 1-off domain that is not registered
            if "l" in dm and dm.replace("l", "1") not in already_tried_spoof_domain:
                spoof_domain = dm.replace("l", "1")
            elif "o" in dm and dm.replace("o", "0") not in already_tried_spoof_domain:
                spoof_domain = dm.replace("o", "0")
            elif "e" in dm and dm.replace("e", "3") not in already_tried_spoof_domain:
                spoof_domain = dm.replace("e", "3")
            elif "i" in dm and dm.replace("i", "l") not in already_tried_spoof_domain:
                spoof_domain = dm.replace("i", "l")
            elif "t" in dm and dm.replace("t", "7") not in already_tried_spoof_domain:
                spoof_domain = dm.replace("t", "7")
            elif "s" in dm and dm.replace("s", "5") not in already_tried_spoof_domain:
                spoof_domain = dm.replace("s", "5")
            elif dm[:-1] + "0" not in already_tried_spoof_domain:
                spoof_domain = dm[:-1] + "0"
            else:
                # FIXME: Rework this so that replacing a letter with it's respective capitalization is not possible
                tmpdm = dm
                tmplist = list(tmpdm)
                char_pos_in_domain = 0
                while tmpdm not in already_tried_spoof_domain or char_pos_in_domain > len(dm):
                    tmplist[char_pos_in_domain] = random.choice(string.ascii_letters)
                    tmpdm = ''.join(tmplist)
                    if tmpdm not in already_tried_spoof_domain:
                        spoof_domain = tmpdm
                        break
                    char_pos_in_domain += 1

                # if makes thru entire domain and not find invalid domain then break and try appending to domain random characters
                if char_pos_in_domain >= len(dm):
                    alphabet_letters = string.ascii_letters
                    # try appending character to domain
                    for letter in alphabet_letters:
                        if dm + letter not in already_tried_spoof_domain:
                            spoof_domain = dm + letter
                            break
                    # Try prepending character to domain
                    if spoof_domain is None:
                        for letter in alphabet_letters:
                            if letter + dm not in already_tried_spoof_domain:
                                spoof_domain = letter + dm
                                break
                    # Could prepend/append 2 characters but for now just breaking out
                    if spoof_domain is None:
                        break

            already_tried_spoof_domain.append(spoof_domain)

            try:
                result = socket.gethostbyname(spoof_domain + tld)  # finds out if IP associated with spoofed domain, we want this to FAIL or else try another replacement 
            except Exception as e:
                stillvalid = False
            try:
                if private_ip(result):
                    break
                else:
                    # Check if has SPF record, if not then add to domain to test from that is registered and no SPF (Test 9)
                    records = dns.resolver.resolve(spoof_domain + tld, 'TXT')
                    no_spf = True
                    for record in records:
                        if "v=spf" in record:
                            no_spf = False
                            break
                    if no_spf and registered_domain_no_spf_sent < 3:
                        emailFilter.test9(email_filter_output, [spoof_domain + tld])
                        registered_domain_no_spf_sent += 1

            except Exception as e:
                break  # means not valid domain which is what we want

            count_iterations += 1

        if count_iterations > 200:
            email_filter_output.write(print_error("Could not find a spoofed / unregistered domain to use close to the clients."))
            break
        elif not stillvalid:
            # print_bold("THIS IS the spoof domain: " + spoof_domain)
            email_from = client_username + spoof_domain + tld
            email_to = [emailFilter.client_email]
            bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
                "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
                "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
            bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

            # Create the root message and fill in the from, to, and subject headers
            msgRoot = MIMEMultipart('related')
            msgRoot['Subject'] = subject
            msgRoot['From'] = email_from
            msgRoot['To'] = emailFilter.client_email
            msgRoot['Message-Id'] = make_msgid()
            msgRoot['Date'] = formatdate(localtime=True)
            if emailFilter.send_read_receipt_to is not None:
                msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
            msgRoot.preamble = 'This is a multi-part message in MIME format.'
            # Encapsulate the plain and HTML versions of the message body in an
            # 'alternative' part, so message agents can decide which they want to display.
            msgAlternative = MIMEMultipart('alternative')
            msgRoot.attach(msgAlternative)
            msgText = MIMEText(bodytext)
            msgAlternative.attach(msgText)
            # We reference the image in the IMG SRC attribute by the ID we give it below
            msgText = MIMEText(bodyhtml, 'html')
            msgAlternative.attach(msgText)
            
            send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

            # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
            #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

        repetition += 1

# no tld
def test7(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ No tld

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 7)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    client_notoplevel = emailFilter.client_email[:emailFilter.client_email.rfind(".")]
    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an email address with no top level domain to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = client_notoplevel
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)
    # We reference the image in the IMG SRC attribute by the ID we give it below
    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# no domain
def test8(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ No domain

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 8)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an email address alias with no domain to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.client_username
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)
    # We reference the image in the IMG SRC attribute by the ID we give it below
    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# no spf so even if they check SPF records we are good. Only be blocked if they block any domain that does not have SPF records, or do RevDNS lookup
def test9(emailFilter: EmailFilter, email_filter_output: str, domain_to_use: list[str] = None) -> None:
    """ No SPF record so even if they check SPF records we are good. Only be blocked if they block any domain that does not have SPF records, or do RevDNS lookup
    
    Args:
        emailFilter (EmailFilter): EmailFilter object
        email_filter_output (str): output file to write to
        domain_to_use (list[str], optional): list of domains to use for email from. Defaults to None.
    """
    if domain_to_use is None:
        domain_to_use = emailFilter.spoof_domains_no_spf_dmarc_dkim

    for sdnsdd in domain_to_use:
        emailFilter.test_num = str(emailFilter.test_num_prefix + 9) + "." + str(emailFilter.test9_count)
        emailFilter.test9_count += 1

        # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
        emailFilter.email_identification()

        bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed valid external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
        email_from = emailFilter.invalid_user_name + '@' + sdnsdd
        email_to = [emailFilter.client_email]
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
        
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# masked url (hidden link) - no Plain text alternative
def test10(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Masked url (hidden link) - no Plain text alternative

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 10)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    additional_headers = '\nContent-Type: Multipart/Related; boundary="00123"\n MIME-version: 1.0\n\n--00123\nContent-Type: Text/HTML; charset=ISO-8859-1\n)Content-Transfer-Encoding: 7bit'
    body = "<html>This is a mail relay test " + emailFilter.test_num + ", from a spoofed valid external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an masked url. \n\n<a href='http://www.yahoo.com'>www.google.com</a>\n\n	<b>Please forward to <a href=mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>.\n\n Thank you." + emailFilter.encrypted_server_info + "</body></html>"
    body = body.replace("\n", "<br>")
    body = body + emailFilter.test_additional_body_txt
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]  # emailFilter.invalid_user_name+'@'+emailFilter.spoof_domain_no_spf_dmarc_dkim[0]+' '
    email_to = [emailFilter.client_email]
    message = "From: " + email_from + "\nTo: " + email_to[0] + "\nSubject: " + subject + additional_headers + "\n\n" + body
    
    
    emailFilter.sending_email(email_from, email_to, message, email_filter_output, email_from, email_to)

# mixed spoofed internal username w/ valid external to internal address
# spoofed DATA FROM but not SMTP FROM
def test11(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Mixed spoofed internal username w/ valid external to internal address,
        spoofed DATA FROM but not SMTP FROM

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 11)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed internal address mixed with valid external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)

    email_from_spoof = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_from = email_from_spoof
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = emailFilter.client_email
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_tosending_email
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# .exe attachment
def test12(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ .exe attachment

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 12)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an executable attachement. \n\n Note: The executable file is benign. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)

    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'calc.exe')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)

        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.exe"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".exe")

        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".exe")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# exe in zip file
def test13(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ exe in zip file

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 13)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an executable enclosed in a zip file attachement. \n\n Note: The executable file is benign. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)

    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt
    
    attachmentfile = os.path.join(emailFilter.attachment_path, 'calc.zip')

    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)

        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="testexe.zip"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".exe.zip")

        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".exe.zip")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# eicar
def test14(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ eicar

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 14)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an eicar test file attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of anti-virus software. For more information about this file, please visit http://www.eicar.org/86-0-Intended-use.html. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)

    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'eicar.txt')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)

        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="eicar.com"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, "eicar")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], "eicar")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")


# eicar in zip file
def test15(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ eicar in zip file

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 15)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an eicar test file enclosed in a zip file as an attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of anti-virus software. For more information about this file, please visit http://www.eicar.org/86-0-Intended-use.html. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'eicar.zip')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="eicar.zip"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, "eicar.zip")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], "eicar.zip")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")


# eicar in zip inside another zip
def test16(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ eicar in zip inside another zip

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 16)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an eicar test file enclosed in a zip file within another zip file as an attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of anti-virus software. For more information about this file, please visit http://www.eicar.org/86-0-Intended-use.html. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'eicar_zip.zip')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="eicar2.zip"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, "eicar.zip.zip")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], "eicar.zip.zip")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# checking SPF (meaning sending from domain that has SPF entries for their domain and we are sending from IP that is not apart of their SPF records)
def test17(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Checking SPF (meaning sending from domain that has SPF entries for their domain and we are sending from IP that is not apart of their SPF records)

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 17)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed valid external address but not from a valid SPF location to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domain_with_spf_hardfail
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
    
    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# checking .gadget exensions
def test18(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Checking .gadget exensions

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 18)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an .gadget test file attachment. \n\n Note: This file is a benign test file that is designed to test effectiveness of filtering .gadget files.. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'thankyou.gadget')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="thankyou.gadget"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".gadget")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".gadget")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")


# .bat
def test19(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ .bat

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 19)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an .bat test file attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of filtering .bat files. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'ver.bat')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="login.bat"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".bat")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".bat")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# Identical to Test10 except also contains plain text alternative (spoofing URL address)
def test20(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Identical to Test10 except also contains plain text alternative (spoofing URL address)

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 20)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed valid external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an masked url with a plain text alternative email message. \n\nhttp://www.yahoo.com\n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[
        0]  # emailFilter.invalid_user_name+'@'+emailFilter.spoof_domain_no_spf_dmarc_dkim[0]+' '
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace("http://www.yahoo.com",
                                                                        "<a href='http://www.yahoo.com'>http://www.google.com</a>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output) 
    
    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# EXFIL
def test21(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ EXFIL

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 21)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", testing exfil paths. \nPort 80:<img src='http://exfil.issgs.net/starwars.jpg?" + emailFilter.encrypted_server_info + "' width=5>\nPort:8080<img src='http://exfil.issgs.net:8080/starwars.jpg?" + emailFilter.encrypted_server_info + "' width=5>\nPort:443<img src='http://exfil.issgs.net:443/starwars.jpg?" + emailFilter.encrypted_server_info + "' width=5>\nPort:64999<img src='http://exfil.issgs.net:64999/starwars.jpg?" + emailFilter.encrypted_server_info + "' width=5><br>" + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output) 
    # send out the email
    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# hta attachment
def test22(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ hta attachment

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 22)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an .HTA attachement. \n\n Note: The HTA file is benign. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'test.hta')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)

        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.hta"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".hta")
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".hta")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# Word Doc w/ Macro attachment
def test23(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Word Doc w/ Macro attachment

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 23)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an attachment of a Word Document that contains a non-malicious macro. \n\n Note: The Word Doc file and Macro are benign. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'test.doc')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)

        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.doc"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".doc (with macro)")

    else:
        print_error("Error: Missing " + attachmentfile + " file which contains a macro for Mail Relay Test " + emailFilter.test_num)

# checking SPF with SoftFail (meaning we send from domain that has a SoftFail SPF entry to end (~all) intead of HardFail (-all)
def test24(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ checking SPF with SoftFail (meaning we send from domain that has a SoftFail SPF entry to end (~all) intead of HardFail (-all)

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 24)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed valid external address but not from a valid SPF location to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " and whose SPF entry ends with a SoftFail (~all) instead of a HardFail (-all). \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domain_with_spf_softfail
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# testing if can send email FROM but have read receipt back to different email
def test25(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ testing if can send email FROM but have read receipt back to different email
 
        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    
    emailFilter.test_num = str(emailFilter.test_num_prefix + 25)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", with a different SEND TO Delivery Notification (read receipt) than the SMTP FROM through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    msgRoot['Disposition-Notification-To'] = emailFilter.forward_email_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# similiar to test25 but SMTP FROM = READ RECEIPT FROM (combo of test 27 & test 25)
def test26(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ similiar to test25 but SMTP FROM = READ RECEIPT FROM (combo of test 27 & test 25)

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 26)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", with a different SEND TO Delivery Notification (read receipt) than the DATA FROM  but same as SMTP FROM through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.forward_email_to
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    msgRoot['Disposition-Notification-To'] = email_from
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
    
    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# spoofed DATA FROM but not SMTP FROM for domain with valid SPF (HardFail from test17)
def test27(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ spoofed DATA FROM but not SMTP FROM for domain with valid SPF (HardFail from test17)

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 27)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed external address with HardFail SPF entry mixed with valid external address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from_spoof = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_from = email_from_spoof
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domain_with_spf_hardfail
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
    
    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])

# SMTP FROM base64 encode but DATA FROM is not (shadow attack)
def test28(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ SMTP FROM base64 encode but DATA FROM is not (shadow attack)

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    """ Thanks to Forrest for this one. """
    try:
        emailFilter.test_num = str(emailFilter.test_num_prefix + 28)

        # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
        emailFilter.email_identification()

        bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a internal address that has the username base64 encoded and no domain portion (shadow attack) and the DATA FROM is a valid internal address that is not base64 encoded through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)

        # email_from_spoof = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
        email_from = "=?UTF-8?B?" + base64.b64encode(emailFilter.client_username.encode('utf-8')).decode('utf-8') + "?= <=?UTF-8?B?" + base64.b64encode(emailFilter.client_username.encode('utf-8')).decode('utf-8') + "?=>"
        email_to = [emailFilter.client_email]
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = emailFilter.client_email
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
    
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])
    except Exception as e:
        print("email filter class 1416 except: " + str(e) + " Error on line {}".format(
            sys.exc_info()[-1].tb_lineno))

# .exe attachment but with extension changed to .txt
def test29(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ .exe attachment but with extension changed to .txt

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 29)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an executable attachement but the .exe extension has been changed to .txt. \n\n Note: The executable file is benign. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'calc.txt')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)

        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="calc.txt"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".exe renamed to .txt")

        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".exe renamed to .txt")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# .exe attachment but with extension changed to .txt but inside a zip file
def test30(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ .exe attachment but with extension changed to .txt but inside a zip file

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 30)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an executable attachement but the .exe extension has been changed to .txt and then put in a zipped file. \n\n Note: The executable file is benign. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'calc_txt.zip')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)

        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="calc_txt.zip"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".exe.zip renamed to .txt.zip")

        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".exe.zip renamed to .txt.zip")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")


# chm
def test31(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ chm

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 31)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an .chm test file attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of filtering .chm files. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'test.chm')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.chm"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".chm")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".chm")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")


# dll
def test32(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ dll

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 32)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is is mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an .dll test file attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of filtering .dll files. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'test.dll')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.dll"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".dll")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".dll")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# mui
def test33(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ mui

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 33)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is is mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an .exe.mui test file attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of filtering .exe.mui files. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'test.exe.mui')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.exe.mui.ln"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".exe.mui.ln")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".exe.mui")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# mui w/o real LN extension
def test34(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ mui w/o real LN extension

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 34)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is is mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an .mui test file attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of filtering .mui files. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'test.mui')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.mui"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".mui")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".mui")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# msi
def test35(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ msi

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 35)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is is mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an .msi test file attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of filtering .msi files. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'test.msi')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.msi"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".msi")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".msi")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# jar
def test36(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ jar

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 36)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with a .jar test file attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of filtering .jar files. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'test.jar')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.jar"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".jar")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".jar")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# scr
def test37(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ scr

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 37)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is is mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an .scr test file attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of filtering .scr files. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'test.scr')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.scr"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".scr")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".scr")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# ps1
def test38(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ ps1

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 38)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is is mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an .ps1 test file attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of filtering .ps1 files. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'test.ps1')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.ps1"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".ps1")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".ps1")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# vbs
def test39(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ vbs

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 39)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is is mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an .vbs test file attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of filtering .vbs files. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'test.vbs')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.vbs"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".vbs")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".vbs")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# sct
def test40(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ sct

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 40)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is is mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an .sct test file attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of filtering .sct files. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'test.sct')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.sct"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".sct")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".sct")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# htm
def test41(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ htm

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 41)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is is mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an .htm test file attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of filtering .htm files. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'test.htm')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.htm"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".htm")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".htm")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# html
def test42(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ html

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 42)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is is mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an .html test file attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of filtering .html files. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'test.sct')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.html"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".html")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".html")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# js
def test43(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ js

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 43)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is is mail relay test " + emailFilter.test_num + ", from an external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an .js test file attachment. \n\n Note: This file is a benign test file that is designed to test the effectiveness of filtering .js files. \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    attachmentfile = os.path.join(emailFilter.attachment_path, 'test.js')
    if os.path.isfile(attachmentfile):
        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        # attach the file
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachmentfile, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="test.js"')
        msgRoot.attach(part)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output, ".js")
        
        # send out the email
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], ".js")
    else:
        print_error(f"Error: Test {emailFilter.test_num}: Missing attachment file: {attachmentfile}")

# spoofed internal SMTP FROM that is base64 encoded
def test44(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ spoofed internal SMTP FROM that is base64 encoded

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    try:
        emailFilter.test_num = str(emailFilter.test_num_prefix + 44)

        # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
        emailFilter.email_identification()

        bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed internal address that is base64 encoded (shadow attack) through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
        email_from = "=?UTF-8?B?" + base64.b64encode(emailFilter.client_username.encode('utf-8')).decode('utf-8') + "?= <>"
        email_to = [emailFilter.client_email]
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
    
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])
    except Exception as e:
        print("email filter class 1416 except: " + str(e) + " Error on line {}".format(sys.exc_info()[-1].tb_lineno))

# spoofed internal SMTP FROM that is base64 encoded & DATA FROM is just username section
def test45(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ spoofed internal SMTP FROM that is base64 encoded & DATA FROM is just username section

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    try:
        emailFilter.test_num = str(emailFilter.test_num_prefix + 45)

        # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
        emailFilter.email_identification()

        bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed internal address that is base64 encoded and only contains the username portion of the email (shadow attack) through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
        email_from = "=?UTF-8?B?" + base64.b64encode(emailFilter.client_username.encode('utf-8')).decode('utf-8') + "?= <>"
        email_to = [emailFilter.client_email]
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = emailFilter.client_username + "<>"
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
    
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'])
    except Exception as e:
        print("email filter class 1416 except: " + str(e) + " Error on line {}".format(
            sys.exc_info()[-1].tb_lineno))

# Resent-From is valid internal (by way of) and SMTP FROM same as TEST 9
def test46(emailFilter: EmailFilter, email_filter_output: str, domain_to_use: list[str] = None):
    """ Resent-From is valid internal (by way of) and SMTP FROM same as TEST 9
    
        Args:
        emailFilter (EmailFilter): EmailFilter object
        email_filter_output (str): output file to write to
        domain_to_use (list[str], optional): list of domains to use for email from. Defaults to None.
    """
    if domain_to_use is None:
        domain_to_use = emailFilter.spoof_domains_no_spf_dmarc_dkim

    for sdnsdd in domain_to_use:
        emailFilter.test_num = str(emailFilter.test_num_prefix + 46)

        # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
        emailFilter.email_identification()

        bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed valid external address with 'resent-from' or by-way-of a valid internal address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
        email_from = emailFilter.invalid_user_name + '@' + sdnsdd
        email_to = [emailFilter.client_email]
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        msgRoot['Resent-From'] = emailFilter.client_email
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
    
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, emailFilter.client_email)

# Resent-From is spoofed (by way of) and SMTP FROM is same as Test 3
def test47(emailFilter: EmailFilter, email_filter_output: str, domain_to_use: list[str] = None):
    """ Resent-From is spoofed (by way of) and SMTP FROM is same as Test 3
    
        Args:
        emailFilter (EmailFilter): EmailFilter object
        email_filter_output (str): output file to write to
        domain_to_use (list[str], optional): list of domains to use for email from. Defaults to None.
    """

    if domain_to_use is None:
        domain_to_use = emailFilter.spoof_domains_no_spf_dmarc_dkim

    for sdnsdd in domain_to_use:
        emailFilter.test_num = str(emailFilter.test_num_prefix + 47)

        # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
        emailFilter.email_identification()

        bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a valid internal address with 'resent-from' or by-way-of a spoofed external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
        email_from = emailFilter.invalid_user_name + '@' + sdnsdd
        email_to = [emailFilter.client_email]
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = emailFilter.client_email
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        msgRoot['Resent-From'] = emailFilter.invalid_user_name + '@' + sdnsdd
        msgRoot['Sender'] = email_from
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
    
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, email_from)

# Sender header is spoofed external and SMTP FROM is same as Test 3
def test48(emailFilter: EmailFilter, email_filter_output: str, domain_to_use: list[str] = None):
    """ Sender header is spoofed external and SMTP FROM is same as Test 3
    
        Args:
        emailFilter (EmailFilter): EmailFilter object
        email_filter_output (str): output file to write to
        domain_to_use (list[str], optional): list of domains to use for email from. Defaults to None.
    """

    if domain_to_use is None:
        domain_to_use = emailFilter.spoof_domains_no_spf_dmarc_dkim

    for sdnsdd in domain_to_use:
        emailFilter.test_num = str(emailFilter.test_num_prefix + 48)

        # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
        emailFilter.email_identification()

        bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a valid internal address with 'sender' or on-behalf-of a spoofed external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
        email_from = emailFilter.invalid_user_name + '@' + sdnsdd
        email_to = [emailFilter.client_email]
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = emailFilter.client_email
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        msgRoot['Sender'] = email_from
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
    
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", email_from)

# Sender header is spoofed external and SMTP FROM is same as Test 3
def test49(emailFilter: EmailFilter, email_filter_output: str, domain_to_use: list[str] = None):
    """ Sender header is spoofed external and SMTP FROM is same as Test 3
    
        Args:
        emailFilter (EmailFilter): EmailFilter object
        email_filter_output (str): output file to write to
        domain_to_use (list[str], optional): list of domains to use for email from. Defaults to None.
    """

    if domain_to_use is None:
        domain_to_use = emailFilter.spoof_domains_no_spf_dmarc_dkim

    for sdnsdd in domain_to_use:
        emailFilter.test_num = str(emailFilter.test_num_prefix + 49)

        # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
        emailFilter.email_identification()

        bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed external address with 'sender' or on-behalf-of a valid internal address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
        email_from = emailFilter.invalid_user_name + '@' + sdnsdd
        email_to = [emailFilter.client_email]
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        msgRoot['Sender'] = emailFilter.client_email
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# SMTP FROM domain is localhost
def test50(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ SMTP FROM domain is localhost

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 

    emailFilter.test_num = str(emailFilter.test_num_prefix + 50)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed external address with domain of 'localhost' through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.client_username + '@localhost'
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    msgRoot['Sender'] = emailFilter.client_email
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# SMTP FROM domain is 127.0.0.1
def test51(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ SMTP FROM domain is 127.0.0.1

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 

    emailFilter.test_num = str(emailFilter.test_num_prefix + 51)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed external address with domain '[127.0.0.1]' through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.client_username + '@[127.0.0.1]'
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    msgRoot['Sender'] = emailFilter.client_email
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# SMTP FROM domain is null
def test52(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ SMTP FROM domain is null

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 

    emailFilter.test_num = str(emailFilter.test_num_prefix + 52)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed external address with null domain, '<>', through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = '<>'
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    msgRoot['Sender'] = emailFilter.client_email
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# Sender email to use FQDN of local host
def test53(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Sender email to use FQDN of local host

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 

    emailFilter.test_num = str(emailFilter.test_num_prefix + 53)

    local_fqdn = get_full_hostname_of_local_computer()

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed external address with domain of scanners local FQDN through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.client_username + '@' + local_fqdn
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    msgRoot['Sender'] = emailFilter.client_email
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# SMTP FROM email to use External IP as domain
def test54(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ SMTP FROM email to use External IP as domain

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 

    emailFilter.test_num = str(emailFilter.test_num_prefix + 54)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed external address with domain as an Public IP Address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.client_username + '@[' + emailFilter.your_public_ip + ']'
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    msgRoot['Sender'] = emailFilter.client_email
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# SMTP FROM email to use Private IP as domain
def test55(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ SMTP FROM email to use Private IP as domain

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 

    emailFilter.test_num = str(emailFilter.test_num_prefix + 55)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed external address with domain as a Private IP Address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.client_username + '@[' + emailFilter.private_ip + ']'
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    msgRoot['Sender'] = emailFilter.client_email
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# SMTP FROM email to use % hack where routing is valid user + % + domain
def test56(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ SMTP FROM email to use % hack where routing is valid user + % + domain

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 

    emailFilter.test_num = str(emailFilter.test_num_prefix + 56)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed internal routed address using the % hack with SMTP FROM in the from: your_username%your_domain@mydomain through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.client_username + '%' + emailFilter.domain + '@' + emailFilter.testers_domain
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    msgRoot['Sender'] = emailFilter.client_email
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# SMTP FROM email to use % hack where routing is valid user but not valid domain
def test57(emailFilter: EmailFilter, email_filter_output: str, spoofed_domain_list: list[str] = None) -> None:
    """ SMTP FROM email to use % hack where routing is valid user but not valid domain

    Args:
        emailFilter (EmailFilter): EmailFilter object
        email_filter_output (str): output file to write to
        spoofed_domain_list (list[str], optional): list of domains to spoof. Defaults to None.
    """

    if spoofed_domain_list is None:
        spoofed_domain_list = emailFilter.spoof_domains_no_spf_dmarc_dkim

    for count, sdl in enumerate(spoofed_domain_list):
        emailFilter.test_num = str(emailFilter.test_num_prefix + 57) + "." + str(count)

        # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
        emailFilter.email_identification()

        bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed internal routed address using the % hack with SMTP FROM in the from: your_username%spoofed_domain@mydomain through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
        email_from = emailFilter.client_username + '%' + sdl + '@' + emailFilter.testers_domain
        email_to = [emailFilter.client_email]
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        msgRoot['Sender'] = emailFilter.client_email
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# SMTP FROM email to use % hack where routing is valid user + domain but routing from is Public IP
def test58(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ SMTP FROM email to use % hack where routing is valid user + domain but routing from is Public IP

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 

    emailFilter.test_num = str(emailFilter.test_num_prefix + 58)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed internal routed address using the % hack with SMTP FROM in the from: your_username%your_domain@[public_ip] through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.client_username + '%' + emailFilter.domain + '@[' + emailFilter.your_public_ip + ']'
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    msgRoot['Sender'] = emailFilter.client_email
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "",
    #                     emailFilter.client_email)

# SMTP FROM email to use % hack where routing is valid user but not valid domain & routed from Public IP
def test59(emailFilter: EmailFilter, email_filter_output: str, spoofed_domain_list: list[str] = None) -> None:
    """ SMTP FROM email to use % hack where routing is valid user but not valid domain & routed from Public IP

    Args:
        emailFilter (EmailFilter): EmailFilter object
        email_filter_output (str): output file to write to
        spoofed_domain_list (list[str], optional): list of domains to use for email from. Defaults to None.
    """
    if spoofed_domain_list is None:
        spoofed_domain_list = emailFilter.spoof_domains_no_spf_dmarc_dkim

    for count, sdl in enumerate(spoofed_domain_list):
        emailFilter.test_num = str(emailFilter.test_num_prefix + 59) + "." + str(count)

        # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
        emailFilter.email_identification()

        bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed internal routed address using the % hack with SMTP FROM in the from: your_username%spoofed_domain@[public_ip] through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
        email_from = emailFilter.client_username + '%' + sdl + '@[' + emailFilter.your_public_ip + ']'
        email_to = [emailFilter.client_email]
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        msgRoot['Sender'] = emailFilter.client_email
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# SMTP FROM email to use % hack where routing is valid user & domain but routing is Public IP of email_server
def test60(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ SMTP FROM email to use % hack where routing is valid user & domain but routing is Public IP of email_server

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 

    emailFilter.test_num = str(emailFilter.test_num_prefix + 60)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    if emailFilter.email_public_ip is not None and valid_ip(emailFilter.email_public_ip):
        bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed internal routed address using the % hack with SMTP FROM in the from: your_username%spoofed_domain@[your_mx_public_ip] through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
        email_from = emailFilter.client_username + '%' + emailFilter.domain + '@[' + emailFilter.email_public_ip + ']'
        email_to = [emailFilter.client_email]
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        msgRoot['Sender'] = emailFilter.client_email
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)
    else :
        print_error(f"Error: Test 60: email_public_ip: {emailFilter.email_public_ip if emailFilter.email_public_ip is not None else 'The IP'} is not set or is not a valid IP address")

# SMTP FROM email if client email in quotes
def test61(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ SMTP FROM email if client email in quotes

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 

    emailFilter.test_num = str(emailFilter.test_num_prefix + 61)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed internal address within quotes through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = '"' + emailFilter.client_email + '"'
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    msgRoot['Sender'] = emailFilter.client_email
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# SMTP FROM email if client email in quotes + % hack from valid user + valid domain
def test62(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ SMTP FROM email if client email in quotes + % hack from valid user + valid domain

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 

    emailFilter.test_num = str(emailFilter.test_num_prefix + 62)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed internal routed address using the % hack with SMTP FROM in the from: your_username%your_domain@mydomain within quotes through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = '"' + emailFilter.client_username + '%' + emailFilter.domain + '@' + emailFilter.testers_domain + '"'
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    msgRoot['Sender'] = emailFilter.client_email
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# SMTP FROM email if client email in quotes + % hack from valid user + valid domain and routed is Public IP
def test63(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ SMTP FROM email if client email in quotes + % hack from valid user + valid domain and routed is Public IP

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 

    emailFilter.test_num = str(emailFilter.test_num_prefix + 63)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed internal routed address using the % hack with SMTP FROM in the from: your_username%your_domain@ip_address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = '"' + emailFilter.client_username + '%' + emailFilter.domain + '"@[' + emailFilter.your_public_ip + ']'
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    msgRoot['Sender'] = emailFilter.client_email
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# SMTP TO email uses source routing (client_email @ domain_list
def test64(emailFilter: EmailFilter, email_filter_output: str, spoofed_domain_list: list[str] = None) -> None:
    """ SMTP TO email uses source routing (client_email @ domain_list

    Args:
        emailFilter (EmailFilter): EmailFilter object
        email_filter_output (str): output file to write to
        spoofed_domain_list (list[str], optional): list of domains to use for email from. Defaults to None.
    """
    if spoofed_domain_list is None:
        spoofed_domain_list = emailFilter.spoof_domains_no_spf_dmarc_dkim

    for count, sdl in enumerate(spoofed_domain_list):
        emailFilter.test_num = str(emailFilter.test_num_prefix + 64) + "." + str(count)

        # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
        emailFilter.email_identification()
        bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed source routed (SMTP TO) address, using the format: your_username@your_domain@spoofed_domain through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
        email_from = "@" + sdl + "," + emailFilter.client_email
        email_to = emailFilter.client_email  # [emailFilter.client_email + "@" + sdl]
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        msgRoot['Sender'] = emailFilter.client_email
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# SMTP TO email uses source routing (client_email @ domain_list) where client_email is encapsulated in quotes
def test65(emailFilter: EmailFilter, email_filter_output: str, spoofed_domain_list: list[str] = None) -> None:
    """ SMTP TO email uses source routing (client_email @ domain_list) where client_email is encapsulated in quotes
    
    Args:
        emailFilter (EmailFilter): EmailFilter object
        email_filter_output (str): output file to write to
        spoofed_domain_list (list[str], optional): list of domains to use for email from. Defaults to None.
    """
    if spoofed_domain_list is None:
        spoofed_domain_list = emailFilter.spoof_domains_no_spf_dmarc_dkim

    for count, sdl in enumerate(spoofed_domain_list):
        emailFilter.test_num = str(emailFilter.test_num_prefix + 65) + "." + str(count)

        # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
        emailFilter.email_identification()
        bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed source routed (SMTP TO) address, using the format: \"your_username@your_domain\"@spoofed_domain through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
        email_from = f'"{emailFilter.client_email}"@{sdl}'  # emailFilter.invalid_user_name + '@' + sdl
        email_to = emailFilter.client_email  # ['"' + emailFilter.client_email + '"@' + sdl]
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        msgRoot['Sender'] = emailFilter.client_email
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# SMTP TO email uses source routing (client_email @ PUBLIC IP)
def test66(emailFilter: EmailFilter, email_filter_output: str, spoofed_domain_list: list[str] = None) -> None:
    """ SMTP TO email uses source routing (client_email @ PUBLIC IP)

    Args:
        emailFilter (EmailFilter): EmailFilter object
        email_filter_output (str): output file to write to
        spoofed_domain_list (list[str], optional): list of domains to use for email from. Defaults to None.
    """
    if spoofed_domain_list is None:
        spoofed_domain_list = emailFilter.spoof_domains_no_spf_dmarc_dkim

    for count, sdl in enumerate(spoofed_domain_list):
        emailFilter.test_num = str(emailFilter.test_num_prefix + 66) + "." + str(count)

        # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
        emailFilter.email_identification()

        bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed internal routed address using the % hack with SMTP FROM in the from: your_username%your_domain@ip_address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
        email_from = emailFilter.client_username + '%' + emailFilter.domain + '@[' + emailFilter.your_ip_address + ']'
        email_to = emailFilter.client_email
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        msgRoot['Sender'] = emailFilter.client_email
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                        msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)

# SMTP TO email uses source routing (client_email @ Public IP of email_server)
def test67(emailFilter: EmailFilter, email_filter_output: str, spoofed_domain_list: list[str] = None) -> None:
    """ SMTP TO email uses source routing (client_email @ Public IP of email_server)

    Args:
        emailFilter (EmailFilter): EmailFilter object
        email_filter_output (str): output file to write to
        spoofed_domain_list (list[str], optional): list of domains to use for email from. Defaults to None.
    """
    if spoofed_domain_list is None:
        spoofed_domain_list = emailFilter.spoof_domains_no_spf_dmarc_dkim    

    if emailFilter.email_public_ip is not None and valid_ip(emailFilter.email_public_ip):
        for count, sdl in enumerate(spoofed_domain_list):
            emailFilter.test_num = str(emailFilter.test_num_prefix + 67) + "." + str(count)

            # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
            emailFilter.email_identification()
            bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed internal routed address using the % hack with SMTP FROM in the from: your_username%spoofed_domain@[your_mx_public_ip] through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
            #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
            subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                            emailFilter.test_additional_msg)
            email_from = emailFilter.client_username + '%' + sdl + '@[' + emailFilter.email_public_ip + ']'  # emailFilter.invalid_user_name + "@" + sdl
            email_to = emailFilter.client_email  # [emailFilter.client_email + '@[' + emailFilter.email_public_ip + ']']

            bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
                "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
                "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
            bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

            # Create the root message and fill in the from, to, and subject headers
            msgRoot = MIMEMultipart('related')
            msgRoot['Subject'] = subject
            msgRoot['From'] = email_from
            msgRoot['To'] = emailFilter.client_email
            msgRoot['Message-Id'] = make_msgid()
            msgRoot['Date'] = formatdate(localtime=True)
            msgRoot['Sender'] = emailFilter.client_email
            if emailFilter.send_read_receipt_to is not None:
                msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
            msgRoot.preamble = 'This is a multi-part message in MIME format.'
            # Encapsulate the plain and HTML versions of the message body in an
            # 'alternative' part, so message agents can decide which they want to display.
            msgAlternative = MIMEMultipart('alternative')
            msgRoot.attach(msgAlternative)
            msgText = MIMEText(bodytext)
            msgAlternative.attach(msgText)

            msgText = MIMEText(bodyhtml, 'html')
            msgAlternative.attach(msgText)
            
            send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

            # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
            #                     msgRoot['To'], msgRoot['Disposition-Notification-To'], None, "", emailFilter.client_email)
    else:
        print_error(f"Error: Test 67: email_public_ip: {emailFilter.email_public_ip if emailFilter.email_public_ip is not None else 'The IP'} is not set or is not a valid IP address")

# URL Spoofing by using html <base href which prepends to all links
def test68(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ URL Spoofing by using html <base href which prepends to all links

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 68)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed valid external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an 'baseStriker method' url with a plain text alternative email message. \n\nhttp://www.yahoo.com\n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[
        0]  # emailFilter.invalid_user_name+'@'+emailFilter.spoof_domains_no_spf_dmarc_dkim[0]+' '
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><head><base href='https://microsoft.com'></head><body>" + bodytext.replace("\n","<br>").\
        replace("http://www.yahoo.com", "<a href='google.com'>google.com</a>").\
        replace("Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
    
    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                        msgRoot['To'], msgRoot['Disposition-Notification-To'])

# Spoof IP of originating email server
def test69(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Spoof IP of originating email server

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 69)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed the Original Email Server's IP through " + emailFilter.email_server + emailFilter.test_additional_msg + " by modifying the SMTP header 'X-Originating-IP'.\n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@microsoft.com'  # Use Microsoft b/c Spoofed X-Originating-IP is Microsoft's IP + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]  # emailFilter.invalid_user_name+'@'+emailFilter.spoof_domains_no_spf_dmarc_dkim[0]+' '
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot['X-Originating-IP'] = '23.103.156.74'  # host microsoft-com.mail.protection.outlook.com (microsoft's mx record)
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
    
    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                        msgRoot['To'], msgRoot['Disposition-Notification-To'])

# Folding / Unfolding SMTP Headers (https://tools.ietf.org/html/rfc2822#section-2.2.3)
def test70(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Folding / Unfolding SMTP Headers (https://tools.ietf.org/html/rfc2822#section-2.2.3)

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 70)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed, valid, internal email using SMTP 'folding/unfolding' through " + emailFilter.email_server + emailFilter.test_additional_msg + ".\n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = " \r\n" + emailFilter.client_email
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
    
    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                        msgRoot['To'], msgRoot['Disposition-Notification-To'])

# SMTP From Header longer than 998 chars
def test71(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ SMTP From Header longer than 998 chars

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 71)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an extremely long SMTP From email address (longer than the max length of 998) through " + emailFilter.email_server + emailFilter.test_additional_msg + ".\n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.client_username + ''.join(random.choices(string.ascii_uppercase, k=999)) + '@' + emailFilter.domain
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
        "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
        "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                        msgRoot['To'], msgRoot['Disposition-Notification-To'])

# Base64 encode display name portion that can proceed email address (and put title, etc to make it long and block out the real email address when displayed in Outlook)
def test72(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ Base64 encode display name portion that can proceed email address (and put title, etc to make it long and block out the real email address when displayed in Outlook)

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    try:
        emailFilter.test_num = str(emailFilter.test_num_prefix + 72)

        # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
        emailFilter.email_identification()

        bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed internal address, display name portion, that is base64 encoded and contains an external email address not base64 encoded (modified shadow attack) through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
        #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
        subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to, emailFilter.test_additional_msg)
        email_from = "=?UTF-8?B?" + base64.b64encode(emailFilter.client_username.encode(
            'utf-8') + " - Chief Information Officer - Certified Managerial Board Member".encode(
            'utf-8') + "?= <".encode('utf-8') + emailFilter.invalid_user_name.encode('utf-8') + "@".encode('utf-8') +
                                                        emailFilter.spoof_domains_no_spf_dmarc_dkim[0].encode(
                                                            'utf-8') + ">".encode('utf-8')).decode('utf-8')
        email_to = [emailFilter.client_email]
        bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
            "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
            "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
        bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

        # Create the root message and fill in the from, to, and subject headers
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = email_from
        msgRoot['To'] = emailFilter.client_email
        msgRoot['Message-Id'] = make_msgid()
        msgRoot['Date'] = formatdate(localtime=True)
        if emailFilter.send_read_receipt_to is not None:
            msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText(bodytext)
        msgAlternative.attach(msgText)

        msgText = MIMEText(bodyhtml, 'html')
        msgAlternative.attach(msgText)
        
        send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
        
        # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
        #                    msgRoot['To'], msgRoot['Disposition-Notification-To'])
    except Exception as e:
        print("email filter class 3575 except: " + str(e) + " Error on line {}".format(
            sys.exc_info()[-1].tb_lineno))

# internal spoof of valid sub-domain
def test73(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ internal spoof of valid sub-domain

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 73)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    # find valid subdomain for emailFilter.domain
    valid_subdomains = []
    for drecord in emailFilter.dns_records:
        ip = find_dns_records(drecord)
        if ip is not None and ip.strip() != "" and valid_ip(ip) and emailFilter.domain in drecord:
            valid_subdomains.append(drecord)
        elif has_whois(drecord) and emailFilter.domain in drecord:
            valid_subdomains.append(drecord)
    count = 0
    if not valid_subdomains:
        print_error(f"Error: Test 73: No valid subdomains found for {emailFilter.domain}. Check that you have added the subdomains in the format: subdomain.domain.com")
    else:
        for subdomain in valid_subdomains:
            if subdomain != emailFilter.domain:
                bodytext = "This is a mail relay test " + emailFilter.test_num + ", from an internal subdomain of the real domain from the email address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + ". \n\n Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
                #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
                subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                                emailFilter.test_additional_msg)
                email_from = 'clawasneverhere@' + subdomain
                email_to = [emailFilter.client_email]
                bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>").replace(
                    "Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
                    "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
                bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

                # Create the root message and fill in the from, to, and subject headers
                msgRoot = MIMEMultipart('related')
                msgRoot['Subject'] = subject
                msgRoot['From'] = 'clawasneverhere@' + subdomain
                msgRoot['To'] = emailFilter.client_email
                msgRoot['Message-Id'] = make_msgid()
                msgRoot['Date'] = formatdate(localtime=True)
                if emailFilter.send_read_receipt_to is not None:
                    msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
                msgRoot.preamble = 'This is a multi-part message in MIME format.'
                # Encapsulate the plain and HTML versions of the message body in an
                # 'alternative' part, so message agents can decide which they want to display.
                msgAlternative = MIMEMultipart('alternative')
                msgRoot.attach(msgAlternative)
                msgText = MIMEText(bodytext)
                msgAlternative.attach(msgText)
                # We reference the image in the IMG SRC attribute by the ID we give it below
                msgText = MIMEText(bodyhtml, 'html')
                msgAlternative.attach(msgText)
                
                send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

                # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
                #                        msgRoot['To'], msgRoot['Disposition-Notification-To'])
                count += 1
            if count > 5: #only try 6 sub-domains
                break

# spoof link using @
def test74(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ spoof link using @

        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 74)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed valid external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an masked URL using url hack routing with a plain text alternative email message. \n\nhttp://www.yahoo.com\n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]  # emailFilter.invalid_user_name+'@'+emailFilter.spoof_domains_no_spf_dmarc_dkim[0]+' '
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>"). \
        replace("http://www.yahoo.com", "<a href='https://google.com@www.microsoft.com'>https://google.com</a>"). \
        replace("Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
                "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                            msgRoot['To'], msgRoot['Disposition-Notification-To'])

# check for microsoft record and try emailing straight there
def test75(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ check for microsoft record and try emailing straight there
    
        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to

    """
    emailFilter.test_num = str(emailFilter.test_num_prefix + 75)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", sending through mail.protection.outlook.com through " + emailFilter.email_server + emailFilter.test_additional_msg + " with an masked URL using url hack routing with a plain text alternative email message. \n\nhttp://www.yahoo.com\n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[
        0]  # emailFilter.invalid_user_name+'@'+emailFilter.spoof_domains_no_spf_dmarc_dkim[0]+' '
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>"). \
        replace("http://www.yahoo.com",
                "<a href='https://google.com@www.microsoft.com'>https://google.com</a>"). \
        replace("Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
                "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)
    
    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                            msgRoot['To'], msgRoot['Disposition-Notification-To'])

# pass URL with yahoo redirect
# https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwjiiojcmtn3AhVVHs0KHQOuALIQFnoECCMQAQ&url=https%3A%2F%2Fen.wiktionary.org%2Fwiki%2Fhead&usg=AOvVaw0zZ62tXgv30rXxX_7cD-ig
# https://r.search.yahoo.com/_ylt=AwrE1.G2mHxiSnQA_x9XNyoA;_ylu=Y29sbwNiZjEEcG9zAzEEdnRpZAMEc2VjA3Ny/RV=2/RE=1652361527/RO=10/RU=https%3a%2f%2fwww.merriam-webster.com%2fdictionary%2fhead/RK=2/RS=GZVWqYLuPKcf78P1jySrmIM6Pd8-
def test77(emailFilter: EmailFilter, email_filter_output: str) -> None:
    """ pass URL with yahoo redirect
        
        Args:
            emailFilter (EmailFilter): EmailFilter object
            email_filter_output (str): output file to write to
    """ 
    emailFilter.test_num = str(emailFilter.test_num_prefix + 77)

    # create the encrypted email identification text at bottom of every email (unencrypted shows scanner IP and path of client dir being worked on so can dump results back to that same location)
    emailFilter.email_identification()

    bodytext = "This is a mail relay test " + emailFilter.test_num + ", from a spoofed valid external address to an internal address through " + emailFilter.email_server + emailFilter.test_additional_msg + " using an masked URL by redirecting through a yahoo link with a plain text alternative email message. \n\nhttp://www.yahoo.com\n\n	Please forward to " + emailFilter.forward_email_to + " prior to deleting this message.\n\n Thank you." + emailFilter.encrypted_server_info
    #subject = "Testing Mail Relay " + emailFilter.test_num + " through " + emailFilter.email_server + emailFilter.test_additional_msg + ". Forward to " + emailFilter.forward_email_to + "!"
    subject = replace_wording(emailFilter.subject, emailFilter.test_num, emailFilter.email_server, emailFilter.forward_email_to,
                                    emailFilter.test_additional_msg)
    email_from = emailFilter.invalid_user_name + '@' + emailFilter.spoof_domains_no_spf_dmarc_dkim[0]  # emailFilter.invalid_user_name+'@'+emailFilter.spoof_domains_no_spf_dmarc_dkim[0]+' '
    email_to = [emailFilter.client_email]
    bodyhtml = "<html><body>" + bodytext.replace("\n", "<br>"). \
        replace("http://www.yahoo.com", "<a href='https://r.search.yahoo.com/_ylt=AwrE1.G2mHxiSnQA_x9XNyoA;_ylu=Y29sbwNiZjEEcG9zAzEEdnRpZAMEc2VjA3Ny/RV=2/RE=1652361527/RO=10/RU=https%3a%2f%2fwww.microsoft.com/RK=2/RS=GZVWqYLuPKcf78P1jySrmIM6Pd8-'>https://google.com</a>"). \
        replace("Please forward to " + emailFilter.forward_email_to + " prior to deleting this message",
                "<b>Please forward to <a href='mailto:" + emailFilter.forward_email_to + "'>" + emailFilter.forward_email_to + "</a> prior to deleting this message</b>") + "</body></html>"
    bodyhtml = bodyhtml + emailFilter.test_additional_body_txt

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = email_from
    msgRoot['To'] = emailFilter.client_email
    msgRoot['Message-Id'] = make_msgid()
    msgRoot['Date'] = formatdate(localtime=True)
    if emailFilter.send_read_receipt_to is not None:
        msgRoot['Disposition-Notification-To'] = emailFilter.send_read_receipt_to
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText(bodytext)
    msgAlternative.attach(msgText)

    msgText = MIMEText(bodyhtml, 'html')
    msgAlternative.attach(msgText)
    
    send_individual_email(emailFilter, msgRoot, email_from, email_to, email_filter_output)

    # emailFilter.sending_email(email_from, email_to, msgRoot.as_string(), email_filter_output, msgRoot['From'],
    #                        msgRoot['To'], msgRoot['Disposition-Notification-To'])
    
    
def create_test_email(emailFilter: EmailFilter, test_num: int, email_filter_output: str, body_text:str, body_html: str):
    emailFilter.test_num = str(emailFilter.test_num_prefix + test_num)
    emailFilter.email_identification()
    body_text = body_text + emailFilter.encrypted_server_info
    
