# Email Filter Testing

## Description
This is designed to test the email filters of a given client. It will send a series of emails to a given email address, each with their own test case.

## Installation
1. Go to the [Package registry](https://git.issgs.net/external-penetration-test/email-filter-testing/-/packages) page and click on the latest package.
    - Scroll down to "Assets" and click on the .whl file to download it.
2. SCP over the file to the scanner box.
3. Install the package on the scanner box using pip3 or preferably pipx (not currently installed on the scanner boxes)
    ```bash
    pip3 install emailfilter-NEWEST-VERSION-py3-none-any.whl
    ```
    WARNING: If an older version has already been installed:
    ```bash
    pip3 install emailfilter-NEWEST-VERSION-py3-none-any.whl --force-reinstall
    ```
    WARNING: If you get the following error:
    ```bash
    ERROR: emailfilter-NEWEST-VERSION-py3-none-any(1).whl is not a supported wheel on this platform.
    ``` 
    - You need to remove the "(1)" from the file name

4. Run the program.
    - If you get an error, make sure that things that you pip install are in path
        1. Check/add the pip install path to your .bashrc or .zshrc file
            ```bash
            export PATH="~/.local/bin:$PATH"
            ```
        2. Source the file
            ```bash
            source PATH/TO/.zshrc or PATH/TO/.bashrc
            ```
### Arguments
```
usage: emailFilterTest [-h] [-v] [-e EMAIL_SERVER_FILE] [-t NUMBER_OF_SECONDS_DELAY] [-a ATTACHMENTS_FOLDER] [-o OUTPUT_DIR] [--subject SUBJECT] [-et EMAIL_TESTS [EMAIL_TESTS ...]] -s SUB_DOMAIN_FILE -to CLIENT_EMAIL_ADDRESS -id EXTERNAL_IDENTIFICATION

Email Filter Testing

options:
  -h, --help            show this help message and exit
  -v, --version         show program's version number and exit
  -e EMAIL_SERVER_FILE, --email_server_file EMAIL_SERVER_FILE
                        File containing list of email gateways to test (MX records, etc). If ommitted, will attempt to use Microsoft MX record for client domain specified in the -to flag
  -t NUMBER_OF_SECONDS_DELAY, --number_of_seconds_delay NUMBER_OF_SECONDS_DELAY
                        Number of seconds to delay between each test, typically should be > 200 (default is 201)
  -a ATTACHMENTS_FOLDER, --attachments_folder ATTACHMENTS_FOLDER
                        Path to folder containing attachments. Defaults to /pentest2022/email-relay/advanced/email_attachments
  -o OUTPUT_DIR, --output_dir OUTPUT_DIR
                        Directory to save output files (smtp logs, .json logs, .eml files) Defaults to results
  --subject SUBJECT     Custom subject line for emails. Defaults to "Testing Mail Relay TESTNUM through EMAILSERVER. Forward to FORWARDTOEMAIL!"
  -et EMAIL_TESTS [EMAIL_TESTS ...], --email_tests EMAIL_TESTS [EMAIL_TESTS ...]
                        List of specific email tests to run as a list of integers (Ex.: 1 4 10 8 7)

required named arguments:
  -s SUB_DOMAIN_FILE, --sub_domain_file SUB_DOMAIN_FILE
                        File containing a list of sub-domains of client domain (Example: vpn.example.com)
  -to CLIENT_EMAIL_ADDRESS, --client_email_address CLIENT_EMAIL_ADDRESS
                        Email address to send these test email filter messages to
  -id EXTERNAL_IDENTIFICATION, --external_identification EXTERNAL_IDENTIFICATION
                        External Identification number
```
## Usage
Basic usage:
```bash
emailFilterTest -e mailServers.txt -t 300 -o results -s subDomains.txt -to email@issgs.net -id 2s34s12412234h353lk5323l5kjh34534 -a /pentest2022/email-relay/advanced/email_attachments/
```
Send only specific tests that don't have attachments:
```bash
emailFilterTest -e mailServers.txt -t 300 -o results -s subDomains.txt -to email@issgs.net -id 2s34s12412234h353lk5323l5kjh34534 -a literallywhatever(not used but still need something) -et 1 4 10 8 7
```
Send only specific tests that have attachments:
```bash
emailFilterTest -e mailServers.txt -t 300 -o results -s subDomains.txt -to email@issgs.net -id 2s34s12412234h353lk5323l5kjh34534 -a /pentest2022/email-relay/advanced/email_attachments/ -et 12 13 14 15 16
```
Minimal usage that will only attempt to send emails to the client email address using the Microsoft MX record for the client domain:
```bash
emailFilterTest -o results -s subDomains.txt -to email@issgs.net -id 2s34s12412234h353lk5323l5kjh34534 -a /pentest2022/email-relay/advanced/email_attachments/
```
Change the subject line of the email:
- There has been a case where the email filter in the subject line contained a blocked word, so this is a way to get around that
```bash
emailFilterTest -e mailServers.txt -o results -s subDomains.txt -to email@issgs.net -id 2s34s12412234h353lk5323l5kjh34534 -a /pentest2022/email-relay/advanced/email_attachments/ --subject "Testing Mail Relay #TESTNUM. Forward to FORWARDTOEMAIL!"
```

## Tests

| Test Number | Description | Additional Notes |
| ----------- | ----------- | ---------------- |
| 0 | should be valid email (so has proper SPF and Rev DNS) used to verify they are not blacklisting us | Currently using mail.issgs.net |
| 1 | Open relay to from anyone external to anyone external | Only run if the email server is not an email server that we are using to bounce emails back from which is currently none |
| 2 | Open relay from valid internal to anyone external | Only run if the email server is not an email server that we are using to bounce emails back from which is currently none |
| 3 | Send to valid internal email from valid internal email | ex: From: name@domain.com To: name@domain.com
| 4 | Send to valid internal email from invalid internal email | ex: From: clawasneverhere@issgs.net To: name@domain.com |
| 5 | Spoof TLD | ex: From: name@domain.c0m |
| 6 | Spoof domain | 5 times with different variations, google.com becomes g00gle.com |
| 7 | No domain  | ex: From: name@google |
| 8 | No top level | ex: From: name |
| 9 | Valid email from no SPF domain, should get thru unless Rev DNS used | ex: From: clawasneverhere@dolekemp96.org |
| 10 | masked url (hidden link) - no Plain text alternative | ex: <a href='hxxp://www.yahoo.com'\>www.google.com</a\> |
| 11 | spoofed from, smtp from is different than body FROM | |
| 12 | Test .exe | |
| 13 | Test .exe in zip | |
| 14 | Test eicar | |
| 15 | Test eicar in zip | |
| 16 | Test eicar in zip in zip | |
| 17 | test SPF (so send from microsoft.com, instead of contoso.com) | meaning sending from domain that has SPF entries for their domain and we are sending from IP that is not apart of their SPF records |
| 18 | test .gadget | |
| 19 | test .bat | |
| 20 | identical to #10, except contains plain text alternative | |
| 21 | test EXFIL | Not currently being used, (<img src for 22,80,443,53,8080,64999), must have these ports open and listening somewhere accessible from the Internet for this test to mean anything |
| 22 | test .hta files | |
| 23 | test Word Doc w/ Macro files | |
| 24 | test SPF SoftFail | ~all in SPF record |
| 25 | with read receipt email differing from SMTP FROM email | Not currently being used |
| 26 | with read receipt email differing from DATA FROM email but same as SMTP FROM | |
| 27 | spoof domain used in test17 by SMTP FROM for only the DATA FROM | SMTP FROM is same as test17 |
| 28 | SMTP FROM base64 encode but DATA FROM is not (shadow attack) | |
| 29 | .exe attachment with renamed extension as .txt | |
| 30 | .exe attachment with renamed extension as .txt inside zip | |
| 31 | .chm attachment | |
| 32 | .dll attachment | |
| 33 | .mui attachment | |
| 34 | .mui attachment without LN extension | |
| 35 | .msi attachment | |
| 36 | .jar attachment | |
| 37 | .scr attachment | |
| 38 | .ps1 attachment | |
| 39 | .vbs attachment | |
| 40 | .sct attachment | |
| 41 | .htm attachment | |
| 42 | .html attachment | |
| 43 | .js attachment | |
| 44 | both SMTP FROM and DATA FROM are base64 encoded (shadow attack) | |
| 45 | SMTP FROM base64 encoded and DATA FROM is just username (shadow attack) | |
| 46 | Resent-From (by way of) is valid internal and SMTP FROM is spoofed | ex: From: clawasneverhere@dolekemp96.org To: name@domain.com Resent-From: name@domain.com |
| 47 | Resent-From (by way of) is spoofed and SMTP FROM is valid internal | ex: From: name@domain.com To: name@domain.com Resent-From: clawasneverhere@dolekemp96.org |
| 48 | Sender (on behalf of) is spoofed and SMTP FROM is valid internal | ex: From: name@domain.com To: name@domain.com Sender: clawasneverhere@dolekemp96.org  |
| 49 | Sender (on behalf of) is valid internal and SMTP FROM is spoofed | ex: From: clawasneverhere@dolekemp96.org To: name@domain.com Sender: name@domain.com |
| 50 | Sender domain is localhost | ex: From: name@localhost|
| 51 | Sender domain is IP localhost - [127.0.0.1] | ex: From: name@[127.0.0.1]
| 52 | null sender address | ex: From: <> |
| 53 | Sender address used local hostname | Not currently being used |
| 54 | Sender address uses Public IP of local host @[1.2.3.4] | ex: From: name@[1.2.3.4]
| 55 | Sender address uses Private IP of local host | ex: From: name@[10.10.1.38] |
| 56 | Sender email to use % hack where routing is valid user + % + domain | ex: From: name%domain.com@domain.com |
| 57 | Sender email to use % hack where routing is valid user but not valid domain | ex: From: name%dolekemp96.org@domain.com, could send multiple times | 
| 58 | Sender email to use % hack where routing is valid user + domain but routing from is Public IP | ex: From: name%domain.com@[1.2.3.4] |
| 59 | Sender email to use % hack where routing is valid user but not valid domain & routed from Public IP | could send multiple times |
| 60 | SMTP FROM email to use % hack where routing is valid user & domain but routing is Public IP of email_server | |
| 61 | SMTP FROM email if client email in quotes | ex: "name@domain.com" |
| 62 | SMTP FROM email if client email in quotes + % hack from valid user + valid domain | ex: "name%domain.com@domain.com" |
| 63 | SMTP FROM email if client email in quotes + % hack from valid user + valid domain and routed is Public IP | ex: name%domain.com@[1.2.3.4]
| 64 | SMTP TO email uses source routing (client_email @ domain_list) | ex: From: @dolekemp96.org,name@domain.com, could send multiple times |
| 65 | SMTP TO email uses source routing (client_email @ domain_list) where client_email is encapsulated in quotes | ex: 'name@domain.com"@dolekemp96.org, could send multiple times |
| 66 | SMTP TO email uses source routing (client_email @ PUBLIC IP) | ex: From: name%domain.com@[1.2.5.4], could send multiple times |
| 67 | SMTP TO email uses source routing (client_email @ Public IP of email_server) | ex: From: name@domain.com@[1.2.3.4], could send multiple times |
| 68 | base Striker URL approach | ex: <base a href='hxxps://microsoft.com'\> <a href='google.com'\> |
| 69 | X-Originator-IP spoofing | ex: X-Originating-IP: 1.2.3.4 |
| 70 | folding/unfolding in SMTP From | |
| 71 | Extremely long SMTP From (longer than 998 chars) | ex: From: nameLNMDHSJ...ODJGPMGLOR@domain.com |
| 72 | Base64 encode display name portion that can proceed email address (and put title, etc to make it long and block out the real email address when displayed in Outlook) | ex: From: =?UTF-8?B?bG1...ZWtlbXA5Ni5vcmc+ |
| 73 | spoof an existent sub-domain of the client domain | ex: From: clawasneverhere@subdomain.domain.com, Sends up to 6 times with different variations provided by the subdomains file |
| 74 | spoof link using @ | ex: <a href='hxxps://google.com@www.microsoft.com'\>hxxps://google.com</a\> |
| 75 | send direct to microsoft using clients domain prepended | Not currently being used |
| 76 | spoof link using tinyurl | Not currently being used |
| 77 | spoof link using yahoo redirect | Not currently being used |

## Development
### Requirements
* Python 3.8+
* pip3
* virtualenv
### Setup
1. Clone the repo
    ```bash
    git clone https://git.issgs.net/external-penetration-test/email-filter-testing.git
    ```
2. Create a virtual environment
    ```bash
    python3 -m venv .
    ```
3. Activate the virtual environment
    ```bash
    source bin/activate
    ```
4. Install the requirements
    ```bash
    pip3 install -r requirements.txt
    ```
5. Run the program with the extra secret hidden `--debug` flag to bypass group and timing restrictions
    ```bash
    cd advanced
    python src/email_filter.py -e mailServers.txt -t 0 -o results -s subDomains.txt -to email@issgs.net -id 2s34s12 -a utils/email_attachments/ --debug
    ```
6. Ask me how to create a release/merge request and I'll show you how to do it
## Credits
* [Kevin Huber](https://git.issgs.net/khuber) - Wrote pretty much this whole thing
* [Garret Wahlstedt](https://git.issgs.net/GWahlstedt) - Helped with the CreateEML function